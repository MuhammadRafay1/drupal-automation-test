
# OAuth 2 Bearer token



Documentation for accessing and setting credentials for openId.

## Auth Credentials

| Name | Type | Description | Getter |
|  --- | --- | --- | --- |
| AccessToken | `String` | The OAuth 2.0 Access Token to use for API requests. | `access_token` |



**Note:** Auth credentials can be set using `OpenIdCredentials` object, passed in as named parameter `open_id_credentials` in the client initialization.

## Usage Example

### Client Initialization

You must provide credentials in the client as shown in the following code snippet.

```ruby
client = QualityOnDemand::Client.new(
  open_id_credentials: OpenIdCredentials.new(
    access_token: 'AccessToken'
  )
)
```


