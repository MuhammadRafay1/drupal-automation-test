
# Qos Status Enum

The current status of the requested QoS session. The status can be one of the following:

* `REQUESTED` - QoS has been requested by creating a session
* `AVAILABLE` - The requested QoS has been provided by the network
* `UNAVAILABLE` - The requested QoS cannot be provided by the network due to some reason

## Enumeration

`QosStatusEnum`

## Fields

| Name |
|  --- |
| `REQUESTED` |
| `AVAILABLE` |
| `UNAVAILABLE` |

