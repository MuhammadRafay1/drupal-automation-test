
# Code 6 Enum

Code given to this error

## Enumeration

`Code6Enum`

## Fields

| Name |
|  --- |
| `IDENTIFIER_MISMATCH` |
| `SERVICE_NOT_APPLICABLE` |
| `MISSING_IDENTIFIER` |
| `UNSUPPORTED_IDENTIFIER` |
| `UNNECESSARY_IDENTIFIER` |

