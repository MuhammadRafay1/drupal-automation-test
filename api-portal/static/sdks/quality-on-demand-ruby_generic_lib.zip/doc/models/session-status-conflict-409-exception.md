
# Session Status Conflict 409 Exception

## Structure

`SessionStatusConflict409Exception`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status` | `Integer` | Required, Constant | HTTP status code returned along with this error response<br><br>**Value**: `409` |
| `code` | `String` | Required, Constant | Code given to this error<br><br>**Value**: `'QUALITY_ON_DEMAND.SESSION_EXTENSION_NOT_ALLOWED'` |
| `message` | `String` | Required | Detailed error description |

## Example (as JSON)

```json
{
  "status": 409,
  "code": "QUALITY_ON_DEMAND.SESSION_EXTENSION_NOT_ALLOWED",
  "message": "message4"
}
```

