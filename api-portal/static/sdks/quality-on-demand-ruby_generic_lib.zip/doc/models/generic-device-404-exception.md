
# Generic Device 404 Exception

## Structure

`GenericDevice404Exception`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status` | `Integer` | Required, Constant | HTTP status code returned along with this error response<br><br>**Value**: `404` |
| `code` | [`Code1Enum`](../../doc/models/code-1-enum.md) | Required | Code given to this error |
| `message` | `String` | Required | Detailed error description |

## Example (as JSON)

```json
{
  "status": 404,
  "code": "NOT_FOUND",
  "message": "message2"
}
```

