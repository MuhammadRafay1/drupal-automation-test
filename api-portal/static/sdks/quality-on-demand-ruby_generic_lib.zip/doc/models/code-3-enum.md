
# Code 3 Enum

Code given to this error

## Enumeration

`Code3Enum`

## Fields

| Name |
|  --- |
| `QUOTA_EXCEEDED` |
| `TOO_MANY_REQUESTS` |

