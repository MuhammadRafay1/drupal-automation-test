
# Plain Credential

A plain credential as a combination of an identifier and a secret. MUST not be used in this API version.

## Structure

`PlainCredential`

## Inherits From

[`SinkCredential`](../../doc/models/sink-credential.md)

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `identifier` | `String` | Required | The identifier might be an account or username. |
| `secret` | `String` | Required | The secret might be a password or passphrase. |

## Example (as JSON)

```json
{
  "credentialType": "PLAIN",
  "identifier": "identifier2",
  "secret": "secret0"
}
```

