
# Data

Event details depending on the event type

## Structure

`Data`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `session_id` | `UUID \| String` | Required | Session ID in UUID format |
| `qos_status` | [`EventQosStatusEnum`](../../doc/models/event-qos-status-enum.md) | Required | The current status of a requested or previously available session. Applicable values in the event are:<br><br>* `AVAILABLE` - The requested QoS has been provided by the network.<br>* `UNAVAILABLE` - A requested or previously available QoS session is now unavailable. `statusInfo` may provide additional information about the reason for the unavailability. |
| `status_info` | [`StatusInfoEnum`](../../doc/models/status-info-enum.md) | Optional | Reason for the new `qosStatus`. Currently `statusInfo` is only applicable when `qosStatus` is 'UNAVAILABLE'.<br><br>* `DURATION_EXPIRED` - Session terminated due to requested duration expired<br>* `NETWORK_TERMINATED` - Network terminated the session before the requested duration expired<br>* `DELETE_REQUESTED`- User requested the deletion of the session before the requested duration expired |

## Example (as JSON)

```json
{
  "sessionId": "0000032c-0000-0000-0000-000000000000",
  "qosStatus": "AVAILABLE",
  "statusInfo": "DELETE_REQUESTED"
}
```

