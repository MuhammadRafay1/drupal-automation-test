
# Device Ipv 4 Addr

## Structure

`DeviceIpv4Addr`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `public_address` | `String` | Required | A single IPv4 address with no subnet mask |
| `private_address` | `String` | Required | A single IPv4 address with no subnet mask |
| `public_port` | `Integer` | Optional | TCP or UDP port number<br><br>**Constraints**: `>= 0`, `<= 65535` |

## Example (as JSON)

```json
{
  "publicAddress": "203.0.113.0",
  "privateAddress": "203.0.113.0",
  "publicPort": 242
}
```

