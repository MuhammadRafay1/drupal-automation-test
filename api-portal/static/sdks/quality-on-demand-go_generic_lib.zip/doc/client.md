
# Client Class Documentation

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| apiRoot | `string` | API root, defined by the service provider, e.g. `api.example.com` or `api.example.com/somepath`<br>*Default*: `"http://localhost:9091"` |
| environment | `Environment` | The API environment. <br> **Default: `Environment.PRODUCTION`** |
| httpConfiguration | [`HttpConfiguration`](../doc/http-configuration.md) | Configurable http client options like timeout and retries. |
| openIdCredentials | [`OpenIdCredentials`](auth/oauth-2-bearer-token.md) | The Credentials Setter for OAuth 2 Bearer token |
| notificationsBearerAuthCredentials | [`NotificationsBearerAuthCredentials`](auth/oauth-2-bearer-token-1.md) | The Credentials Setter for OAuth 2 Bearer token |

The API client can be initialized as follows:

```go
client := qualityondemand.NewClient(
    qualityondemand.CreateConfiguration(
        qualityondemand.WithHttpConfiguration(
            qualityondemand.CreateHttpConfiguration(
                qualityondemand.WithTimeout(0),
            ),
        ),
        qualityondemand.WithEnvironment(qualityondemand.PRODUCTION),
        qualityondemand.WithOpenIdCredentials(
            qualityondemand.NewOpenIdCredentials("AccessToken"),
        ),
        qualityondemand.WithNotificationsBearerAuthCredentials(
            qualityondemand.NewNotificationsBearerAuthCredentials("AccessToken"),
        ),
        qualityondemand.WithApiRoot("http://localhost:9091"),
    ),
)
```

## Quality-On-Demand Client

The gateway for the SDK. This class acts as a factory for the Controllers and also holds the configuration of the SDK.

## Controllers

| Name | Description |
|  --- | --- |
| QoSSessionsController() | Gets QoSSessionsController |

