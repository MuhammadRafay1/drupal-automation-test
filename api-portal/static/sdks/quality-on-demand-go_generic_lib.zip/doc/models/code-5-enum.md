
# Code 5 Enum

Code given to this error

## Enumeration

`Code5Enum`

## Fields

| Name |
|  --- |
| `INVALIDARGUMENT` |
| `OUTOFRANGE` |
| `ENUMQUALITYONDEMANDDURATIONOUTOFRANGE` |

