
# Device Ipv 4 Addr

## Structure

`DeviceIpv4Addr`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PublicAddress` | `string` | Required | A single IPv4 address with no subnet mask |
| `PrivateAddress` | `string` | Required | A single IPv4 address with no subnet mask |
| `PublicPort` | `*int` | Optional | TCP or UDP port number<br><br>**Constraints**: `>= 0`, `<= 65535` |

## Example (as JSON)

```json
{
  "publicAddress": "203.0.113.0",
  "privateAddress": "203.0.113.0",
  "publicPort": 242
}
```

