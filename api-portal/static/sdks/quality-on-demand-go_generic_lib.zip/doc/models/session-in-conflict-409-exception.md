
# Session in Conflict 409 Exception

## Structure

`SessionInConflict409Exception`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Status` | `int` | Required, Constant | HTTP status code returned along with this error response<br><br>**Value**: `409` |
| `Code` | `string` | Required, Constant | Code given to this error<br><br>**Value**: `"CONFLICT"` |
| `Message` | `string` | Required | Detailed error description |

## Example (as JSON)

```json
{
  "status": 409,
  "code": "CONFLICT",
  "message": "message8"
}
```

