
# Sink Credential

## Structure

`SinkCredential`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CredentialType` | `*string` | Optional | - |

## Example (as JSON)

```json
{
  "credentialType": "SinkCredential"
}
```

