
# Code Enum

Code given to this error

## Enumeration

`CodeEnum`

## Fields

| Name |
|  --- |
| `INVALIDARGUMENT` |
| `OUTOFRANGE` |
| `ENUMQUALITYONDEMANDDURATIONOUTOFRANGE` |
| `INVALIDCREDENTIAL` |
| `INVALIDTOKEN` |

