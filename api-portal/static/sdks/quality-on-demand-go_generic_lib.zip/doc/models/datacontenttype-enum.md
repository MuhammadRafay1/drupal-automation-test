
# Datacontenttype Enum

media-type that describes the event payload encoding, must be "application/json" for CAMARA APIs

## Enumeration

`DatacontenttypeEnum`

## Fields

| Name |
|  --- |
| `ENUMAPPLICATIONJSON` |

