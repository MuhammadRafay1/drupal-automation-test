
# Extend Session Duration

Attributes required to extend the duration of an active session

## Structure

`ExtendSessionDuration`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `RequestedAdditionalDuration` | `int` | Required | Additional duration in seconds to be added to the current session duration. The overall session duration, including extensions, shall not exceed the maximum duration limit for the QoS Profile.<br><br>**Constraints**: `>= 1` |

## Example (as JSON)

```json
{
  "requestedAdditionalDuration": 1800
}
```

