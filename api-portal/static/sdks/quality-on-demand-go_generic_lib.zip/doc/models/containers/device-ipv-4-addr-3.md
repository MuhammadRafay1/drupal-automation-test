
# Device Ipv 4 Addr 3

## Class Name

`DeviceIpv4Addr3`

## Cases

| Type | Factory Method |
|  --- | --- |
| [`models.DeviceIpv4Addr`](../../../doc/models/device-ipv-4-addr.md) | models.DeviceIpv4Addr3Container.FromDeviceIpv4Addr(models.DeviceIpv4Addr deviceIpv4Addr) |
| [`models.DeviceIpv4Addr1`](../../../doc/models/device-ipv-4-addr-1.md) | models.DeviceIpv4Addr3Container.FromDeviceIpv4Addr1(models.DeviceIpv4Addr1 deviceIpv4Addr1) |

