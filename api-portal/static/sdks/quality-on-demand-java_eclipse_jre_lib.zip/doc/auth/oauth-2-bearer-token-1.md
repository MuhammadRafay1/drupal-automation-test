
# OAuth 2 Bearer token



Documentation for accessing and setting credentials for notificationsBearerAuth.

## Auth Credentials

| Name | Type | Description | Setter | Getter |
|  --- | --- | --- | --- | --- |
| AccessToken | `String` | The OAuth 2.0 Access Token to use for API requests. | `accessToken` | `getAccessToken()` |



**Note:** Auth credentials can be set using `notificationsBearerAuthCredentials` in the client builder and accessed through `getNotificationsBearerAuthCredentials` method in the client instance.

## Usage Example

### Client Initialization

You must provide credentials in the client as shown in the following code snippet.

```java
import localhost9091.QualityOnDemandClient;
import localhost9091.authentication.NotificationsBearerAuthModel;

QualityOnDemandClient client = new QualityOnDemandClient.Builder()
    .notificationsBearerAuthCredentials(new NotificationsBearerAuthModel.Builder(
            "AccessToken"
        )
        .build())
    .build();
```


