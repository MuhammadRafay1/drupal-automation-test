
# OAuth 2 Bearer token



Documentation for accessing and setting credentials for openId.

## Auth Credentials

| Name | Type | Description | Setter | Getter |
|  --- | --- | --- | --- | --- |
| AccessToken | `String` | The OAuth 2.0 Access Token to use for API requests. | `accessToken` | `getAccessToken()` |



**Note:** Auth credentials can be set using `openIdCredentials` in the client builder and accessed through `getOpenIdCredentials` method in the client instance.

## Usage Example

### Client Initialization

You must provide credentials in the client as shown in the following code snippet.

```java
import localhost9091.QualityOnDemandClient;
import localhost9091.authentication.OpenIdModel;

QualityOnDemandClient client = new QualityOnDemandClient.Builder()
    .openIdCredentials(new OpenIdModel.Builder(
            "AccessToken"
        )
        .build())
    .build();
```


