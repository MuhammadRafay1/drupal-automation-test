# Qo S Sessions

```java
QoSSessionsController qoSSessionsController = client.getQoSSessionsController();
```

## Class Name

`QoSSessionsController`

## Methods

* [Create Session](../../doc/controllers/qo-s-sessions.md#create-session)
* [Get Session](../../doc/controllers/qo-s-sessions.md#get-session)
* [Delete Session](../../doc/controllers/qo-s-sessions.md#delete-session)
* [Extend Qos Session Duration](../../doc/controllers/qo-s-sessions.md#extend-qos-session-duration)
* [Retrieve Sessions by Device](../../doc/controllers/qo-s-sessions.md#retrieve-sessions-by-device)


# Create Session

Create QoS Session to manage latency/throughput priorities

If the qosStatus in the API response is "AVAILABLE" and a notification callback is provided the API consumer will receive in addition to the response a
`QOS_STATUS_CHANGED` event notification with `qosStatus` as `AVAILABLE`.

If the `qosStatus` in the API response is `REQUESTED`, the client will receive either

- a `QOS_STATUS_CHANGED` event notification with `qosStatus` as `AVAILABLE` after the network notifies that it has created the requested session, or
- a `QOS_STATUS_CHANGED` event notification with `qosStatus` as `UNAVAILABLE` and `statusInfo` as `NETWORK_TERMINATED` after the network notifies that it has failed to provide the requested session.

A `QOS_STATUS_CHANGED` event notification with `qosStatus` as `UNAVAILABLE` will also be send if the network terminates the session before the requested duration expired

**NOTES:**

- In case of a `QOS_STATUS_CHANGED` event with `qosStatus` as `UNAVAILABLE` and `statusInfo` as `NETWORK_TERMINATED` the resources of the QoS session are not directly released, but will get deleted automatically at earliest 360 seconds after the event.
  
  This behavior allows API consumers which are not receiving notification events but are polling to get the session information with the `qosStatus` `UNAVAILABLE` and `statusInfo` `NETWORK_TERMINATED`. Before a API consumer can attempt to create a new QoD session for the same device and flow period they must release the session resources with an explicit `delete` operation if not yet automatically deleted.

- The access token may be either 2-legged or 3-legged. See "Identifying the device from the access token" for further information
  
  - When the API is invoked using a two-legged access token, the subject will be identified from the optional `device` object, which therefore MUST be provided.
  - When a three-legged access token is used however, this optional identifier MUST NOT be provided, as the subject will be uniquely identified from the access token.

```java
CompletableFuture<SessionInfo> createSessionAsync(
    final CreateSession body,
    final String xCorrelator)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`CreateSession`](../../doc/models/create-session.md) | Body, Required | Parameters to create a new session |
| `xCorrelator` | `String` | Header, Optional | Correlation id for the different services<br><br>**Constraints**: *Pattern*: `^[a-zA-Z0-9-]{0,55}$` |

## Requires scope

### openId

`quality-on-demand:sessions:create`

## Response Type

[`SessionInfo`](../../doc/models/session-info.md)

## Example Usage

```java
CreateSession body = new CreateSession.Builder(
    new ApplicationServer.Builder()
        .ipv4Address("198.51.100.0/24")
        .ipv6Address("2001:db8:85a3:8d3:1319:8a2e:370:7344")
        .build(),
    "voice",
    3600
)
.sink("https://endpoint.example.com/sink")
.build();

String xCorrelator = "b4333c46-49c0-4f62-80d7-f0ef930f1c46";

qoSSessionsController.createSessionAsync(body, xCorrelator).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad Request when creating a session | [`CreateSessionBadRequest400Exception`](../../doc/models/create-session-bad-request-400-exception.md) |
| 401 | Unauthorized | [`Generic401Exception`](../../doc/models/generic-401-exception.md) |
| 403 | Forbidden | [`Generic401Exception`](../../doc/models/generic-401-exception.md) |
| 404 | Not found | [`GenericDevice404Exception`](../../doc/models/generic-device-404-exception.md) |
| 409 | Conflict | [`SessionInConflict409Exception`](../../doc/models/session-in-conflict-409-exception.md) |
| 422 | Unprocessable Content | [`CreateSessionUnprocessableEntity422Exception`](../../doc/models/create-session-unprocessable-entity-422-exception.md) |
| 429 | Too Many Requests | [`Generic429Exception`](../../doc/models/generic-429-exception.md) |


# Get Session

Querying for QoS session resource information details

**NOTES:**

- The access token may be either 2-legged or 3-legged.
- If a 3-legged access token is used, the end user (and device) associated with the session must also be associated with the access token.
- The session must have been created by the same API client given in the access token

```java
CompletableFuture<SessionInfo> getSessionAsync(
    final UUID sessionId,
    final String xCorrelator)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sessionId` | `UUID` | Template, Required | Session ID that was obtained from the createSession operation |
| `xCorrelator` | `String` | Header, Optional | Correlation id for the different services<br><br>**Constraints**: *Pattern*: `^[a-zA-Z0-9-]{0,55}$` |

## Requires scope

### openId

`quality-on-demand:sessions:read`

## Response Type

[`SessionInfo`](../../doc/models/session-info.md)

## Example Usage

```java
UUID sessionId = UUID.fromString("00001c50-0000-0000-0000-000000000000");
String xCorrelator = "b4333c46-49c0-4f62-80d7-f0ef930f1c46";

qoSSessionsController.getSessionAsync(sessionId, xCorrelator).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "duration": 3600,
  "device": {
    "ipv4Address": {
      "publicAddress": "203.0.113.0",
      "publicPort": 59765
    }
  },
  "applicationServer": {
    "ipv4Address": "198.51.100.0/24"
  },
  "qosProfile": "QOS_L",
  "sink": "https://application-server.com/notifications",
  "sessionId": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
  "startedAt": "2024-06-01T12:00:00Z",
  "expiresAt": "2024-06-01T13:00:00Z",
  "qosStatus": "AVAILABLE"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad Request | [`Generic400Exception`](../../doc/models/generic-400-exception.md) |
| 401 | Unauthorized | [`Generic401Exception`](../../doc/models/generic-401-exception.md) |
| 403 | Forbidden | [`Generic401Exception`](../../doc/models/generic-401-exception.md) |
| 404 | Not found | [`Generic401Exception`](../../doc/models/generic-401-exception.md) |
| 429 | Too Many Requests | [`Generic429Exception`](../../doc/models/generic-429-exception.md) |


# Delete Session

Release resources related to QoS session

If the notification callback is provided and the `qosStatus` of the session was `AVAILABLE` the client will receive in addition to the response a `QOS_STATUS_CHANGED` event with

- `qosStatus` as `UNAVAILABLE` and
- `statusInfo` as `DELETE_REQUESTED`
  There will be no notification event if the `qosStatus` was already `UNAVAILABLE`.

**NOTES:**

- The access token may be either 2-legged or 3-legged.
- If a 3-legged access token is used, the subject associated with the session must also be associated with the access token.
- The session must must have been created by the same API consumer given in the access token

```java
CompletableFuture<Void> deleteSessionAsync(
    final UUID sessionId,
    final String xCorrelator)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sessionId` | `UUID` | Template, Required | Session ID that was obtained from the createSession operation |
| `xCorrelator` | `String` | Header, Optional | Correlation id for the different services<br><br>**Constraints**: *Pattern*: `^[a-zA-Z0-9-]{0,55}$` |

## Requires scope

### openId

`quality-on-demand:sessions:delete`

## Response Type

`void`

## Example Usage

```java
UUID sessionId = UUID.fromString("00001c50-0000-0000-0000-000000000000");
String xCorrelator = "b4333c46-49c0-4f62-80d7-f0ef930f1c46";

qoSSessionsController.deleteSessionAsync(sessionId, xCorrelator).thenAccept(result -> {
    // TODO success callback handler
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad Request | [`Generic400Exception`](../../doc/models/generic-400-exception.md) |
| 401 | Unauthorized | [`Generic401Exception`](../../doc/models/generic-401-exception.md) |
| 403 | Forbidden | [`Generic401Exception`](../../doc/models/generic-401-exception.md) |
| 404 | Not found | [`Generic401Exception`](../../doc/models/generic-401-exception.md) |
| 429 | Too Many Requests | [`Generic429Exception`](../../doc/models/generic-429-exception.md) |


# Extend Qos Session Duration

Extend the overall session duration of an active QoS session (with qosStatus = AVAILABLE).
The overall duration of the QoS session, including the additional extended duration, shall not exceed the maximum duration limit fixed for the QoS Profile. If the current duration plus the value of `requestedAdditionalDuration` exceeds the maximum limit, the new overall duration shall be capped to the maximum value allowed.
An example: For a QoS profile limited to a `maxDuration` of 50,000 seconds, a QoD session was originally created with duration 30,000 seconds. Before the session expires, the developer requests to extend the session by another 30,000 seconds:

- Previous duration: 30,000 seconds
- Requested additional duration: 30,000 seconds
- New overall session duration: 50,000 seconds (the maximum allowed)

**NOTES:**

- The access token may be either 2-legged or 3-legged.
- If a 3-legged access token is used, the subject associated with the session must also be associated with the access token.
- The session must must have been created by the same API consumer given in the access token

```java
CompletableFuture<SessionInfo> extendQosSessionDurationAsync(
    final UUID sessionId,
    final ExtendSessionDuration body,
    final String xCorrelator)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sessionId` | `UUID` | Template, Required | Session ID that was obtained from the createSession operation |
| `body` | [`ExtendSessionDuration`](../../doc/models/extend-session-duration.md) | Body, Required | Parameters to extend the duration of an active session |
| `xCorrelator` | `String` | Header, Optional | Correlation id for the different services<br><br>**Constraints**: *Pattern*: `^[a-zA-Z0-9-]{0,55}$` |

## Requires scope

### openId

`quality-on-demand:sessions:update`

## Response Type

[`SessionInfo`](../../doc/models/session-info.md)

## Example Usage

```java
UUID sessionId = UUID.fromString("00001c50-0000-0000-0000-000000000000");
ExtendSessionDuration body = new ExtendSessionDuration.Builder(
    1800
)
.build();

String xCorrelator = "b4333c46-49c0-4f62-80d7-f0ef930f1c46";

qoSSessionsController.extendQosSessionDurationAsync(sessionId, body, xCorrelator).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad Request | [`GenericExtendSessionDuration400Exception`](../../doc/models/generic-extend-session-duration-400-exception.md) |
| 401 | Unauthorized | [`Generic401Exception`](../../doc/models/generic-401-exception.md) |
| 403 | Forbidden | [`Generic401Exception`](../../doc/models/generic-401-exception.md) |
| 404 | Not found | [`Generic401Exception`](../../doc/models/generic-401-exception.md) |
| 409 | Conflict | [`SessionStatusConflict409Exception`](../../doc/models/session-status-conflict-409-exception.md) |
| 429 | Too Many Requests | [`Generic429Exception`](../../doc/models/generic-429-exception.md) |


# Retrieve Sessions by Device

Querying for QoS session resource information details for a device

**NOTES:**

- The access token may be either 2-legged or 3-legged.
  - If a 3-legged access token is used, the subject associated with the session must also be associated with the access token. In this case the optional `device` parameter MUST NOT be provided in the request.
  - If a 2-legged access token is used, the device parameter must be provided and identify a device.
- The session must have been created by the same API consumer given in the access token
- If no QoS session is found for the requested device, an empty array is returned.
- This call uses the POST method instead of GET to comply with the CAMARA Commonalities guidelines for sending sensitive or complex data in API calls. Since the device field may contain personally identifiable information, it should not be sent via GET.
  [CAMARA API Design Guidelines](https://github.com/camaraproject/Commonalities/blob/r2.3/documentation/API-design-guidelines.md#post-or-get-for-transferring-sensitive-or-complex-data)

```java
CompletableFuture<List<SessionInfo>> retrieveSessionsByDeviceAsync(
    final RetrieveSessionsInput body,
    final String xCorrelator)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`RetrieveSessionsInput`](../../doc/models/retrieve-sessions-input.md) | Body, Required | Parameters to get QoS session information by device |
| `xCorrelator` | `String` | Header, Optional | Correlation id for the different services<br><br>**Constraints**: *Pattern*: `^[a-zA-Z0-9-]{0,55}$` |

## Requires scope

### openId

`quality-on-demand:sessions:retrieve-by-device`

## Response Type

[`List<SessionInfo>`](../../doc/models/session-info.md)

## Example Usage

```java
RetrieveSessionsInput body = new RetrieveSessionsInput.Builder()
    .build();

String xCorrelator = "b4333c46-49c0-4f62-80d7-f0ef930f1c46";

qoSSessionsController.retrieveSessionsByDeviceAsync(body, xCorrelator).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Example Response *(as JSON)*

```json
[
  {
    "duration": 3600,
    "device": {
      "phoneNumber": "+123456789"
    },
    "applicationServer": {
      "ipv4Address": "0.0.0.0/0"
    },
    "qosProfile": "QOS_L",
    "sink": "https://application-server.com/notifications",
    "sessionId": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
    "startedAt": "2024-06-01T12:00:00Z",
    "expiresAt": "2024-06-01T13:00:00Z",
    "qosStatus": "AVAILABLE"
  }
]
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad Request | [`Generic400Exception`](../../doc/models/generic-400-exception.md) |
| 401 | Unauthorized | [`Generic401Exception`](../../doc/models/generic-401-exception.md) |
| 403 | Forbidden | [`Generic401Exception`](../../doc/models/generic-401-exception.md) |
| 404 | Not found | [`GenericDevice404Exception`](../../doc/models/generic-device-404-exception.md) |
| 422 | Unprocessable Content | [`Generic422Exception`](../../doc/models/generic-422-exception.md) |
| 429 | Too Many Requests | [`Generic429Exception`](../../doc/models/generic-429-exception.md) |

