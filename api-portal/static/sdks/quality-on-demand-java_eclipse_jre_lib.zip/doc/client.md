
# Client Class Documentation

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| apiRoot | `String` | API root, defined by the service provider, e.g. `api.example.com` or `api.example.com/somepath`<br>*Default*: `"http://localhost:9091"` |
| environment | `Environment` | The API environment. <br> **Default: `Environment.PRODUCTION`** |
| httpClientConfig | [`Consumer<HttpClientConfiguration.Builder>`](../doc/http-client-configuration-builder.md) | Set up Http Client Configuration instance. |
| openIdCredentials | [`OpenIdCredentials`](auth/oauth-2-bearer-token.md) | The Credentials Setter for OAuth 2 Bearer token |
| notificationsBearerAuthCredentials | [`NotificationsBearerAuthCredentials`](auth/oauth-2-bearer-token-1.md) | The Credentials Setter for OAuth 2 Bearer token |

The API client can be initialized as follows:

```java
import java.io.IOException;
import localhost9091.Environment;
import localhost9091.QualityOnDemandClient;
import localhost9091.authentication.NotificationsBearerAuthModel;
import localhost9091.authentication.OpenIdModel;
import localhost9091.exceptions.ApiException;

QualityOnDemandClient client = new QualityOnDemandClient.Builder()
    .httpClientConfig(configBuilder -> configBuilder
            .timeout(0))
    .openIdCredentials(new OpenIdModel.Builder(
            "AccessToken"
        )
        .build())
    .notificationsBearerAuthCredentials(new NotificationsBearerAuthModel.Builder(
            "AccessToken"
        )
        .build())
    .environment(Environment.PRODUCTION)
    .apiRoot("http://localhost:9091")
    .build();
```

## Quality-On-DemandClient Class

The gateway for the SDK. This class acts as a factory for the Controllers and also holds the configuration of the SDK.

### Controllers

| Name | Description | Return Type |
|  --- | --- | --- |
| `getQoSSessionsController()` | Provides access to QoSSessions controller. | `QoSSessionsController` |

### Methods

| Name | Description | Return Type |
|  --- | --- | --- |
| `shutdown()` | Shutdown the underlying HttpClient instance. | `void` |
| `getEnvironment()` | Current API environment. | `Environment` |
| `getApiRoot()` | API root, defined by the service provider, e.g. `api.example.com` or `api.example.com/somepath` | `String` |
| `getHttpClient()` | The HTTP Client instance to use for making HTTP requests. | `HttpClient` |
| `getHttpClientConfig()` | Http Client Configuration instance. | [`ReadonlyHttpClientConfiguration`](../doc/http-client-configuration.md) |
| `getOpenIdCredentials()` | The credentials to use with OpenId. | [`OpenIdCredentials`](auth/oauth-2-bearer-token.md) |
| `getNotificationsBearerAuthCredentials()` | The credentials to use with NotificationsBearerAuth. | [`NotificationsBearerAuthCredentials`](auth/oauth-2-bearer-token-1.md) |
| `getBaseUri(Server server)` | Get base URI by current environment | `String` |
| `getBaseUri()` | Get base URI by current environment | `String` |

