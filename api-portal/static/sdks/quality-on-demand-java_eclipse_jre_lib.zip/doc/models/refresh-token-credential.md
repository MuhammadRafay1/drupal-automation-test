
# Refresh Token Credential

An access token credential with a refresh token. MUST not be used in this API version.

## Structure

`RefreshTokenCredential`

## Inherits From

[`SinkCredential`](../../doc/models/sink-credential.md)

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AccessToken` | `String` | Required | REQUIRED. An access token is a previously acquired token granting access to the target resource. | String getAccessToken() | setAccessToken(String accessToken) |
| `AccessTokenExpiresUtc` | `LocalDateTime` | Required | REQUIRED. An absolute UTC instant at which the token shall be considered expired. | LocalDateTime getAccessTokenExpiresUtc() | setAccessTokenExpiresUtc(LocalDateTime accessTokenExpiresUtc) |
| `AccessTokenType` | `String` | Required, Constant | REQUIRED. Type of the access token (See [OAuth 2.0](https://tools.ietf.org/html/rfc6749#section-7.1)).<br><br>**Value**: `"bearer"` | String getAccessTokenType() | setAccessTokenType(String accessTokenType) |
| `RefreshToken` | `String` | Required | REQUIRED. An refresh token credential used to acquire access tokens. | String getRefreshToken() | setRefreshToken(String refreshToken) |
| `RefreshTokenEndpoint` | `String` | Required | REQUIRED. A URL at which the refresh token can be traded for an access token. | String getRefreshTokenEndpoint() | setRefreshTokenEndpoint(String refreshTokenEndpoint) |

## Example (as JSON)

```json
{
  "accessToken": "accessToken6",
  "accessTokenExpiresUtc": "2016-03-13T12:52:32.123Z",
  "accessTokenType": "bearer",
  "refreshToken": "refreshToken6",
  "refreshTokenEndpoint": "refreshTokenEndpoint6",
  "credentialType": "REFRESHTOKEN"
}
```

