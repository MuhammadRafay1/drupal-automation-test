
# Device Ipv 4 Addr

## Structure

`DeviceIpv4Addr`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `PublicAddress` | `String` | Required | A single IPv4 address with no subnet mask | String getPublicAddress() | setPublicAddress(String publicAddress) |
| `PrivateAddress` | `String` | Required | A single IPv4 address with no subnet mask | String getPrivateAddress() | setPrivateAddress(String privateAddress) |
| `PublicPort` | `Integer` | Optional | TCP or UDP port number<br><br>**Constraints**: `>= 0`, `<= 65535` | Integer getPublicPort() | setPublicPort(Integer publicPort) |

## Example (as JSON)

```json
{
  "publicAddress": "203.0.113.0",
  "privateAddress": "203.0.113.0",
  "publicPort": 242
}
```

