
# Error Info

Common schema for errors

## Structure

`ErrorInfo`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Status` | `int` | Required | HTTP status code returned along with this error response | int getStatus() | setStatus(int status) |
| `Code` | `String` | Required | Code given to this error | String getCode() | setCode(String code) |
| `Message` | `String` | Required | Detailed error description | String getMessage() | setMessage(String message) |

## Example (as JSON)

```json
{
  "status": 222,
  "code": "code6",
  "message": "message8"
}
```

