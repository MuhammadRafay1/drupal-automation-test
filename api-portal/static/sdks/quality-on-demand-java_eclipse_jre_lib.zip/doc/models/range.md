
# Range

## Structure

`Range`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `From` | `int` | Required | TCP or UDP port number<br><br>**Constraints**: `>= 0`, `<= 65535` | int getFrom() | setFrom(int from) |
| `To` | `int` | Required | TCP or UDP port number<br><br>**Constraints**: `>= 0`, `<= 65535` | int getTo() | setTo(int to) |

## Example (as JSON)

```json
{
  "from": 92,
  "to": 12
}
```

