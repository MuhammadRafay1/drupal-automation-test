
# Generic 422 Exception

## Structure

`Generic422Exception`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Status` | `int` | Required, Constant | HTTP status code returned along with this error response<br><br>**Value**: `422` | int getStatus() | setStatus(int status) |
| `Code` | [`Code6Enum`](../../doc/models/code-6-enum.md) | Required | Code given to this error | Code6Enum getCode() | setCode(Code6Enum code) |
| `Message` | `String` | Required | Detailed error description | String getMessageField() | setMessageField(String messageField) |

## Example (as JSON)

```json
{
  "status": 422,
  "code": "UNNECESSARY_IDENTIFIER",
  "message": "message6"
}
```

