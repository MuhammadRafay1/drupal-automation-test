
# Device Ipv 4 Addr 1

## Structure

`DeviceIpv4Addr1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `PublicAddress` | `String` | Required | A single IPv4 address with no subnet mask | String getPublicAddress() | setPublicAddress(String publicAddress) |
| `PrivateAddress` | `String` | Optional | A single IPv4 address with no subnet mask | String getPrivateAddress() | setPrivateAddress(String privateAddress) |
| `PublicPort` | `int` | Required | TCP or UDP port number<br><br>**Constraints**: `>= 0`, `<= 65535` | int getPublicPort() | setPublicPort(int publicPort) |

## Example (as JSON)

```json
{
  "publicAddress": "203.0.113.0",
  "privateAddress": "203.0.113.0",
  "publicPort": 240
}
```

