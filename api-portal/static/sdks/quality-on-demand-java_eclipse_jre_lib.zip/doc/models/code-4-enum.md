
# Code 4 Enum

Code given to this error

## Enumeration

`Code4Enum`

## Fields

| Name |
|  --- |
| `INVALIDARGUMENT` |
| `OUTOFRANGE` |

