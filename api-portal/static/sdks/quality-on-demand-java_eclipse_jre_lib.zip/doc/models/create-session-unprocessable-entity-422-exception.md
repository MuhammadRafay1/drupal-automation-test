
# Create Session Unprocessable Entity 422 Exception

## Structure

`CreateSessionUnprocessableEntity422Exception`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Status` | `int` | Required, Constant | HTTP status code returned along with this error response<br><br>**Value**: `422` | int getStatus() | setStatus(int status) |
| `Code` | [`Code2Enum`](../../doc/models/code-2-enum.md) | Required | Code given to this error | Code2Enum getCode() | setCode(Code2Enum code) |
| `Message` | `String` | Required | Detailed error description | String getMessageField() | setMessageField(String messageField) |

## Example (as JSON)

```json
{
  "status": 422,
  "code": "UNNECESSARY_IDENTIFIER",
  "message": "message4"
}
```

