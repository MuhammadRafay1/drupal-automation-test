
# Create Session Bad Request 400 Exception

## Structure

`CreateSessionBadRequest400Exception`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Status` | `int` | Required, Constant | HTTP status code returned along with this error response<br><br>**Value**: `400` | int getStatus() | setStatus(int status) |
| `Code` | [`CodeEnum`](../../doc/models/code-enum.md) | Required | Code given to this error | CodeEnum getCode() | setCode(CodeEnum code) |
| `Message` | `String` | Required | Detailed error description | String getMessageField() | setMessageField(String messageField) |

## Example (as JSON)

```json
{
  "status": 400,
  "code": "INVALID_CREDENTIAL",
  "message": "message0"
}
```

