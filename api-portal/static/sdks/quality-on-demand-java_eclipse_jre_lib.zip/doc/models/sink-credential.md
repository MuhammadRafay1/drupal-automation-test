
# Sink Credential

## Structure

`SinkCredential`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `CredentialType` | `String` | Optional | - | String getCredentialType() | setCredentialType(String credentialType) |

## Example (as JSON)

```json
{
  "credentialType": "SinkCredential"
}
```

