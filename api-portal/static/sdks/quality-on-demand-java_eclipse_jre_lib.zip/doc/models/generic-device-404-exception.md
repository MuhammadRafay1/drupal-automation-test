
# Generic Device 404 Exception

## Structure

`GenericDevice404Exception`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Status` | `int` | Required, Constant | HTTP status code returned along with this error response<br><br>**Value**: `404` | int getStatus() | setStatus(int status) |
| `Code` | [`Code1Enum`](../../doc/models/code-1-enum.md) | Required | Code given to this error | Code1Enum getCode() | setCode(Code1Enum code) |
| `Message` | `String` | Required | Detailed error description | String getMessageField() | setMessageField(String messageField) |

## Example (as JSON)

```json
{
  "status": 404,
  "code": "NOT_FOUND",
  "message": "message2"
}
```

