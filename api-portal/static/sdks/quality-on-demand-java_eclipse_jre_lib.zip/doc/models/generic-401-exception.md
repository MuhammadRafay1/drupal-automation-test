
# Generic 401 Exception

## Structure

`Generic401Exception`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Status` | `int` | Required, Constant | HTTP status code returned along with this error response<br><br>**Value**: `401` | int getStatus() | setStatus(int status) |
| `Code` | `String` | Required, Constant | Code given to this error<br><br>**Value**: `"UNAUTHENTICATED"` | String getCode() | setCode(String code) |
| `Message` | `String` | Required | Detailed error description | String getMessageField() | setMessageField(String messageField) |

## Example (as JSON)

```json
{
  "status": 401,
  "code": "UNAUTHENTICATED",
  "message": "message2"
}
```

