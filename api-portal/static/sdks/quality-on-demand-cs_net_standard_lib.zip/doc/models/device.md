
# Device

End-user equipment able to connect to a network. Examples of devices include smartphones or IoT sensors/actuators.

The developer can choose to provide the below specified device identifiers:

* `ipv4Address`
* `ipv6Address`
* `phoneNumber`
* `networkAccessIdentifier`

NOTE1: the network operator might support only a subset of these options. The API consumer can provide multiple identifiers to be compatible across different network operators. In this case the identifiers MUST belong to the same device.
NOTE2: as for this Commonalities release, we are enforcing that the networkAccessIdentifier is only part of the schema for future-proofing, and CAMARA does not currently allow its use. After the CAMARA meta-release work is concluded and the relevant issues are resolved, its use will need to be explicitly documented in the guidelines.

## Structure

`Device`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PhoneNumber` | `string` | Optional | A public identifier addressing a telephone subscription. In mobile networks it corresponds to the MSISDN (Mobile Station International Subscriber Directory Number). In order to be globally unique it has to be formatted in international format, according to E.164 standard, prefixed with '+'.<br><br>**Constraints**: *Pattern*: `^\+[1-9][0-9]{4,14}$` |
| `NetworkAccessIdentifier` | `string` | Optional | A public identifier addressing a subscription in a mobile network. In 3GPP terminology, it corresponds to the GPSI formatted with the External Identifier ({Local Identifier}@{Domain Identifier}). Unlike the telephone number, the network access identifier is not subjected to portability ruling in force, and is individually managed by each operator. |
| `Ipv4Address` | [`DeviceIpv4Addr3`](../../doc/models/containers/device-ipv-4-addr-3.md) | Optional | The device should be identified by either the public (observed) IP address and port as seen by the application server, or the private (local) and any public (observed) IP addresses in use by the device (this information can be obtained by various means, for example from some DNS servers).<br><br>If the allocated and observed IP addresses are the same (i.e. NAT is not in use) then  the same address should be specified for both publicAddress and privateAddress.<br><br>If NAT64 is in use, the device should be identified by its publicAddress and publicPort, or separately by its allocated IPv6 address (field ipv6Address of the Device object)<br><br>In all cases, publicAddress must be specified, along with at least one of either privateAddress or publicPort, dependent upon which is known. In general, mobile devices cannot be identified by their public IPv4 address alone. |
| `Ipv6Address` | `string` | Optional | The device should be identified by the observed IPv6 address, or by any single IPv6 address from within the subnet allocated to the device (e.g. adding ::0 to the /64 prefix).<br><br>The session shall apply to all IP flows between the device subnet and the specified application server, unless further restricted by the optional parameters devicePorts or applicationServerPorts. |

## Example (as JSON)

```json
{
  "phoneNumber": "+123456789",
  "networkAccessIdentifier": "123456789@domain.com",
  "ipv4Address": {
    "publicAddress": "203.0.113.0",
    "publicPort": 59765,
    "privateAddress": "privateAddress2"
  },
  "ipv6Address": "2001:db8:85a3:8d3:1319:8a2e:370:7344"
}
```

