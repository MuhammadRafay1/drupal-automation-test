
# Device Ipv 4 Addr 3

## Class Name

`DeviceIpv4Addr3`

## Cases

| Type | Factory Method |
|  --- | --- |
| [`DeviceIpv4Addr`](../../../doc/models/device-ipv-4-addr.md) | DeviceIpv4Addr3.FromDeviceIpv4Addr(DeviceIpv4Addr deviceIpv4Addr) |
| [`DeviceIpv4Addr1`](../../../doc/models/device-ipv-4-addr-1.md) | DeviceIpv4Addr3.FromDeviceIpv4Addr1(DeviceIpv4Addr1 deviceIpv4Addr1) |

