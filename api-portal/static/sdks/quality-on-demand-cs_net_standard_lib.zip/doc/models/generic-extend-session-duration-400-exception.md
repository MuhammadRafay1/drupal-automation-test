
# Generic Extend Session Duration 400 Exception

## Structure

`GenericExtendSessionDuration400Exception`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Status` | `int` | Required, Constant | HTTP status code returned along with this error response<br><br>**Value**: `400` |
| `Code` | [`Code5Enum`](../../doc/models/code-5-enum.md) | Required | Code given to this error |
| `Message` | `string` | Required | Detailed error description |

## Example (as JSON)

```json
{
  "status": 400,
  "code": "INVALID_ARGUMENT",
  "message": "message4"
}
```

