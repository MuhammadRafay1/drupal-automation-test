
# Access Token Credential

An access token credential.

## Structure

`AccessTokenCredential`

## Inherits From

[`SinkCredential`](../../doc/models/sink-credential.md)

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AccessToken` | `string` | Required | REQUIRED. An access token is a previously acquired token granting access to the target resource. |
| `AccessTokenExpiresUtc` | `DateTime` | Required | REQUIRED. An absolute (UTC) timestamp at which the token shall be considered expired. Token expiration should occur<br>after the termination of the requested session, allowing the client to be notified of any changes during the<br>sessions's existence. If the token expires while the session is still active, the client will stop receiving notifications.<br>If the access token is a JWT and registered "exp" (Expiration Time) claim is present, the two expiry times should match.<br>It must follow [RFC 3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) and must have time zone.<br>Recommended format is yyyy-MM-dd'T'HH:mm:ss.SSSZ (i.e. which allows 2023-07-03T14:27:08.312+02:00 or 2023-07-03T12:27:08.312Z) |
| `AccessTokenType` | `string` | Required, Constant | REQUIRED. Type of the access token (See [OAuth 2.0](https://tools.ietf.org/html/rfc6749#section-7.1)). For the current version of the API the type MUST be set to `Bearer`.<br><br>**Value**: `"bearer"` |

## Example (as JSON)

```json
{
  "accessToken": "accessToken4",
  "accessTokenExpiresUtc": "07/03/2023 12:27:08",
  "accessTokenType": "bearer",
  "credentialType": "ACCESSTOKEN"
}
```

