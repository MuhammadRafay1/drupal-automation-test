
# Code Enum

Code given to this error

## Enumeration

`CodeEnum`

## Fields

| Name |
|  --- |
| `INVALIDARGUMENT` |
| `OUTOFRANGE` |
| `EnumQUALITYONDEMANDDURATIONOUTOFRANGE` |
| `INVALIDCREDENTIAL` |
| `INVALIDTOKEN` |

