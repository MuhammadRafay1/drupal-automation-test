
# Range

## Structure

`Range`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `From` | `int` | Required | TCP or UDP port number<br><br>**Constraints**: `>= 0`, `<= 65535` |
| `To` | `int` | Required | TCP or UDP port number<br><br>**Constraints**: `>= 0`, `<= 65535` |

## Example (as JSON)

```json
{
  "from": 92,
  "to": 12
}
```

