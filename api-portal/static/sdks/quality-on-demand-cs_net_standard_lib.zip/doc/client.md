
# Client Class Documentation

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| ApiRoot | `string` | API root, defined by the service provider, e.g. `api.example.com` or `api.example.com/somepath`<br>*Default*: `"http://localhost:9091"` |
| Environment | `Environment` | The API environment. <br> **Default: `Environment.Production`** |
| Timeout | `TimeSpan` | Http client timeout.<br>*Default*: `TimeSpan.FromSeconds(100)` |
| HttpClientConfiguration | [`Action<HttpClientConfiguration.Builder>`](../doc/http-client-configuration-builder.md) | Action delegate that configures the HTTP client by using the HttpClientConfiguration.Builder for customizing API call settings.<br>*Default*: `new HttpClient()` |
| OpenIdCredentials | [`OpenIdCredentials`](auth/oauth-2-bearer-token.md) | The Credentials Setter for OAuth 2 Bearer token |
| NotificationsBearerAuthCredentials | [`NotificationsBearerAuthCredentials`](auth/oauth-2-bearer-token-1.md) | The Credentials Setter for OAuth 2 Bearer token |

The API client can be initialized as follows:

```csharp
using QualityOnDemand.Standard;
using QualityOnDemand.Standard.Authentication;

QualityOnDemandClient client = new QualityOnDemandClient.Builder()
    .OpenIdCredentials(
        new OpenIdModel.Builder(
            "AccessToken"
        )
        .Build())
    .NotificationsBearerAuthCredentials(
        new NotificationsBearerAuthModel.Builder(
            "AccessToken"
        )
        .Build())
    .Environment(QualityOnDemand.Standard.Environment.Production)
    .ApiRoot("http://localhost:9091")
    .Build();
```

## Quality-On-DemandClient Class

The gateway for the SDK. This class acts as a factory for the Controllers and also holds the configuration of the SDK.

### Controllers

| Name | Description |
|  --- | --- |
| QoSSessionsController | Gets QoSSessionsController controller. |

### Properties

| Name | Description | Type |
|  --- | --- | --- |
| HttpClientConfiguration | Gets the configuration of the Http Client associated with this client. | [`IHttpClientConfiguration`](../doc/http-client-configuration.md) |
| Timeout | Http client timeout. | `TimeSpan` |
| Environment | Current API environment. | `Environment` |
| ApiRoot | API root, defined by the service provider, e.g. `api.example.com` or `api.example.com/somepath` | `string` |
| OpenIdCredentials | Gets the credentials to use with OpenId. | [`IOpenIdCredentials`](auth/oauth-2-bearer-token.md) |
| NotificationsBearerAuthCredentials | Gets the credentials to use with NotificationsBearerAuth. | [`INotificationsBearerAuthCredentials`](auth/oauth-2-bearer-token-1.md) |

### Methods

| Name | Description | Return Type |
|  --- | --- | --- |
| `GetBaseUri(Server alias = Server.Default)` | Gets the URL for a particular alias in the current environment and appends it with template parameters. | `string` |
| `ToBuilder()` | Creates an object of the Quality-On-DemandClient using the values provided for the builder. | `Builder` |

## Quality-On-DemandClient Builder Class

Class to build instances of Quality-On-DemandClient.

### Methods

| Name | Description | Return Type |
|  --- | --- | --- |
| `HttpClientConfiguration(Action<`[`HttpClientConfiguration.Builder`](../doc/http-client-configuration-builder.md)`> action)` | Gets the configuration of the Http Client associated with this client. | `Builder` |
| `Timeout(TimeSpan timeout)` | Http client timeout. | `Builder` |
| `Environment(Environment environment)` | Current API environment. | `Builder` |
| `ApiRoot(string apiRoot)` | API root, defined by the service provider, e.g. `api.example.com` or `api.example.com/somepath` | `Builder` |
| `OpenIdCredentials(Action<OpenIdModel.Builder> action)` | Sets credentials for OpenId. | `Builder` |
| `NotificationsBearerAuthCredentials(Action<NotificationsBearerAuthModel.Builder> action)` | Sets credentials for NotificationsBearerAuth. | `Builder` |

