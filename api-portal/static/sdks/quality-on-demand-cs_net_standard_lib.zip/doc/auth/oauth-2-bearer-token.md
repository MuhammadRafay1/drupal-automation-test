
# OAuth 2 Bearer token



Documentation for accessing and setting credentials for openId.

## Auth Credentials

| Name | Type | Description | Setter | Getter |
|  --- | --- | --- | --- | --- |
| AccessToken | `string` | The OAuth 2.0 Access Token to use for API requests. | `AccessToken` | `AccessToken` |



**Note:** Auth credentials can be set using `OpenIdCredentials` in the client builder and accessed through `OpenIdCredentials` method in the client instance.

## Usage Example

### Client Initialization

You must provide credentials in the client as shown in the following code snippet.

```csharp
using QualityOnDemand.Standard;
using QualityOnDemand.Standard.Authentication;

QualityOnDemandClient client = new QualityOnDemandClient.Builder()
    .OpenIdCredentials(
        new OpenIdModel.Builder(
            "AccessToken"
        )
        .Build())
    .Build();
```


