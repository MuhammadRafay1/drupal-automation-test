// <copyright file="QoSSessionsController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using APIMatic.Core;
using APIMatic.Core.Types;
using APIMatic.Core.Utilities;
using APIMatic.Core.Utilities.Date.Xml;
using Newtonsoft.Json.Converters;
using QualityOnDemand.Standard;
using QualityOnDemand.Standard.Exceptions;
using QualityOnDemand.Standard.Http.Client;
using QualityOnDemand.Standard.Utilities;
using System.Net.Http;

namespace QualityOnDemand.Standard.Controllers
{
    /// <summary>
    /// QoSSessionsController.
    /// </summary>
    public class QoSSessionsController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="QoSSessionsController"/> class.
        /// </summary>
        internal QoSSessionsController(GlobalConfiguration globalConfiguration) : base(globalConfiguration) { }

        /// <summary>
        /// Create QoS Session to manage latency/throughput priorities.
        /// If the qosStatus in the API response is "AVAILABLE" and a notification callback is provided the API consumer will receive in addition to the response a.
        /// `QOS_STATUS_CHANGED` event notification with `qosStatus` as `AVAILABLE`.
        /// If the `qosStatus` in the API response is `REQUESTED`, the client will receive either.
        /// - a `QOS_STATUS_CHANGED` event notification with `qosStatus` as `AVAILABLE` after the network notifies that it has created the requested session, or.
        /// - a `QOS_STATUS_CHANGED` event notification with `qosStatus` as `UNAVAILABLE` and `statusInfo` as `NETWORK_TERMINATED` after the network notifies that it has failed to provide the requested session.
        /// A `QOS_STATUS_CHANGED` event notification with `qosStatus` as `UNAVAILABLE` will also be send if the network terminates the session before the requested duration expired.
        /// **NOTES:**.
        /// - In case of a `QOS_STATUS_CHANGED` event with `qosStatus` as `UNAVAILABLE` and `statusInfo` as `NETWORK_TERMINATED` the resources of the QoS session are not directly released, but will get deleted automatically at earliest 360 seconds after the event.
        ///   This behavior allows API consumers which are not receiving notification events but are polling to get the session information with the `qosStatus` `UNAVAILABLE` and `statusInfo` `NETWORK_TERMINATED`. Before a API consumer can attempt to create a new QoD session for the same device and flow period they must release the session resources with an explicit `delete` operation if not yet automatically deleted.
        /// - The access token may be either 2-legged or 3-legged. See "Identifying the device from the access token" for further information.
        ///   - When the API is invoked using a two-legged access token, the subject will be identified from the optional `device` object, which therefore MUST be provided.
        ///   - When a three-legged access token is used however, this optional identifier MUST NOT be provided, as the subject will be uniquely identified from the access token.
        /// </summary>
        /// <param name="body">Required parameter: Parameters to create a new session.</param>
        /// <param name="xCorrelator">Optional parameter: Correlation id for the different services.</param>
        /// <returns>Returns the Models.SessionInfo response from the API call.</returns>
        public Models.SessionInfo CreateSession(
                Models.CreateSession body,
                string xCorrelator = null)
            => CoreHelper.RunTask(CreateSessionAsync(body, xCorrelator));

        /// <summary>
        /// Create QoS Session to manage latency/throughput priorities.
        /// If the qosStatus in the API response is "AVAILABLE" and a notification callback is provided the API consumer will receive in addition to the response a.
        /// `QOS_STATUS_CHANGED` event notification with `qosStatus` as `AVAILABLE`.
        /// If the `qosStatus` in the API response is `REQUESTED`, the client will receive either.
        /// - a `QOS_STATUS_CHANGED` event notification with `qosStatus` as `AVAILABLE` after the network notifies that it has created the requested session, or.
        /// - a `QOS_STATUS_CHANGED` event notification with `qosStatus` as `UNAVAILABLE` and `statusInfo` as `NETWORK_TERMINATED` after the network notifies that it has failed to provide the requested session.
        /// A `QOS_STATUS_CHANGED` event notification with `qosStatus` as `UNAVAILABLE` will also be send if the network terminates the session before the requested duration expired.
        /// **NOTES:**.
        /// - In case of a `QOS_STATUS_CHANGED` event with `qosStatus` as `UNAVAILABLE` and `statusInfo` as `NETWORK_TERMINATED` the resources of the QoS session are not directly released, but will get deleted automatically at earliest 360 seconds after the event.
        ///   This behavior allows API consumers which are not receiving notification events but are polling to get the session information with the `qosStatus` `UNAVAILABLE` and `statusInfo` `NETWORK_TERMINATED`. Before a API consumer can attempt to create a new QoD session for the same device and flow period they must release the session resources with an explicit `delete` operation if not yet automatically deleted.
        /// - The access token may be either 2-legged or 3-legged. See "Identifying the device from the access token" for further information.
        ///   - When the API is invoked using a two-legged access token, the subject will be identified from the optional `device` object, which therefore MUST be provided.
        ///   - When a three-legged access token is used however, this optional identifier MUST NOT be provided, as the subject will be uniquely identified from the access token.
        /// </summary>
        /// <param name="body">Required parameter: Parameters to create a new session.</param>
        /// <param name="xCorrelator">Optional parameter: Correlation id for the different services.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.SessionInfo response from the API call.</returns>
        public async Task<Models.SessionInfo> CreateSessionAsync(
                Models.CreateSession body,
                string xCorrelator = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.SessionInfo>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/sessions")
                  .WithAuth("openId")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(body))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Header(_header => _header.Setup("x-correlator", xCorrelator))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("Bad Request when creating a session", (_reason, _context) => new CreateSessionBadRequest400Exception(_reason, _context)))
                  .ErrorCase("401", CreateErrorCase("Unauthorized", (_reason, _context) => new Generic401Exception(_reason, _context)))
                  .ErrorCase("403", CreateErrorCase("Forbidden", (_reason, _context) => new Generic401Exception(_reason, _context)))
                  .ErrorCase("404", CreateErrorCase("Not found", (_reason, _context) => new GenericDevice404Exception(_reason, _context)))
                  .ErrorCase("409", CreateErrorCase("Conflict", (_reason, _context) => new SessionInConflict409Exception(_reason, _context)))
                  .ErrorCase("422", CreateErrorCase("Unprocessable Content", (_reason, _context) => new CreateSessionUnprocessableEntity422Exception(_reason, _context)))
                  .ErrorCase("429", CreateErrorCase("Too Many Requests", (_reason, _context) => new Generic429Exception(_reason, _context))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// Querying for QoS session resource information details.
        /// **NOTES:**.
        /// - The access token may be either 2-legged or 3-legged.
        /// - If a 3-legged access token is used, the end user (and device) associated with the session must also be associated with the access token.
        /// - The session must have been created by the same API client given in the access token.
        /// </summary>
        /// <param name="sessionId">Required parameter: Session ID that was obtained from the createSession operation.</param>
        /// <param name="xCorrelator">Optional parameter: Correlation id for the different services.</param>
        /// <returns>Returns the Models.SessionInfo response from the API call.</returns>
        public Models.SessionInfo GetSession(
                Guid sessionId,
                string xCorrelator = null)
            => CoreHelper.RunTask(GetSessionAsync(sessionId, xCorrelator));

        /// <summary>
        /// Querying for QoS session resource information details.
        /// **NOTES:**.
        /// - The access token may be either 2-legged or 3-legged.
        /// - If a 3-legged access token is used, the end user (and device) associated with the session must also be associated with the access token.
        /// - The session must have been created by the same API client given in the access token.
        /// </summary>
        /// <param name="sessionId">Required parameter: Session ID that was obtained from the createSession operation.</param>
        /// <param name="xCorrelator">Optional parameter: Correlation id for the different services.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.SessionInfo response from the API call.</returns>
        public async Task<Models.SessionInfo> GetSessionAsync(
                Guid sessionId,
                string xCorrelator = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.SessionInfo>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/sessions/{sessionId}")
                  .WithAuth("openId")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("sessionId", sessionId))
                      .Header(_header => _header.Setup("x-correlator", xCorrelator))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("Bad Request", (_reason, _context) => new Generic400Exception(_reason, _context)))
                  .ErrorCase("401", CreateErrorCase("Unauthorized", (_reason, _context) => new Generic401Exception(_reason, _context)))
                  .ErrorCase("403", CreateErrorCase("Forbidden", (_reason, _context) => new Generic401Exception(_reason, _context)))
                  .ErrorCase("404", CreateErrorCase("Not found", (_reason, _context) => new Generic401Exception(_reason, _context)))
                  .ErrorCase("429", CreateErrorCase("Too Many Requests", (_reason, _context) => new Generic429Exception(_reason, _context))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// Release resources related to QoS session.
        /// If the notification callback is provided and the `qosStatus` of the session was `AVAILABLE` the client will receive in addition to the response a `QOS_STATUS_CHANGED` event with.
        /// - `qosStatus` as `UNAVAILABLE` and.
        /// - `statusInfo` as `DELETE_REQUESTED`.
        /// There will be no notification event if the `qosStatus` was already `UNAVAILABLE`.
        /// **NOTES:**.
        /// - The access token may be either 2-legged or 3-legged.
        /// - If a 3-legged access token is used, the subject associated with the session must also be associated with the access token.
        /// - The session must must have been created by the same API consumer given in the access token.
        /// </summary>
        /// <param name="sessionId">Required parameter: Session ID that was obtained from the createSession operation.</param>
        /// <param name="xCorrelator">Optional parameter: Correlation id for the different services.</param>
        public void DeleteSession(
                Guid sessionId,
                string xCorrelator = null)
            => CoreHelper.RunVoidTask(DeleteSessionAsync(sessionId, xCorrelator));

        /// <summary>
        /// Release resources related to QoS session.
        /// If the notification callback is provided and the `qosStatus` of the session was `AVAILABLE` the client will receive in addition to the response a `QOS_STATUS_CHANGED` event with.
        /// - `qosStatus` as `UNAVAILABLE` and.
        /// - `statusInfo` as `DELETE_REQUESTED`.
        /// There will be no notification event if the `qosStatus` was already `UNAVAILABLE`.
        /// **NOTES:**.
        /// - The access token may be either 2-legged or 3-legged.
        /// - If a 3-legged access token is used, the subject associated with the session must also be associated with the access token.
        /// - The session must must have been created by the same API consumer given in the access token.
        /// </summary>
        /// <param name="sessionId">Required parameter: Session ID that was obtained from the createSession operation.</param>
        /// <param name="xCorrelator">Optional parameter: Correlation id for the different services.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the void response from the API call.</returns>
        public async Task DeleteSessionAsync(
                Guid sessionId,
                string xCorrelator = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<VoidType>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Delete, "/sessions/{sessionId}")
                  .WithAuth("openId")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("sessionId", sessionId))
                      .Header(_header => _header.Setup("x-correlator", xCorrelator))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("Bad Request", (_reason, _context) => new Generic400Exception(_reason, _context)))
                  .ErrorCase("401", CreateErrorCase("Unauthorized", (_reason, _context) => new Generic401Exception(_reason, _context)))
                  .ErrorCase("403", CreateErrorCase("Forbidden", (_reason, _context) => new Generic401Exception(_reason, _context)))
                  .ErrorCase("404", CreateErrorCase("Not found", (_reason, _context) => new Generic401Exception(_reason, _context)))
                  .ErrorCase("429", CreateErrorCase("Too Many Requests", (_reason, _context) => new Generic429Exception(_reason, _context))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// Extend the overall session duration of an active QoS session (with qosStatus = AVAILABLE).
        /// The overall duration of the QoS session, including the additional extended duration, shall not exceed the maximum duration limit fixed for the QoS Profile. If the current duration plus the value of `requestedAdditionalDuration` exceeds the maximum limit, the new overall duration shall be capped to the maximum value allowed.
        /// An example: For a QoS profile limited to a `maxDuration` of 50,000 seconds, a QoD session was originally created with duration 30,000 seconds. Before the session expires, the developer requests to extend the session by another 30,000 seconds:.
        /// - Previous duration: 30,000 seconds.
        /// - Requested additional duration: 30,000 seconds.
        /// - New overall session duration: 50,000 seconds (the maximum allowed).
        /// **NOTES:**.
        /// - The access token may be either 2-legged or 3-legged.
        /// - If a 3-legged access token is used, the subject associated with the session must also be associated with the access token.
        /// - The session must must have been created by the same API consumer given in the access token.
        /// </summary>
        /// <param name="sessionId">Required parameter: Session ID that was obtained from the createSession operation.</param>
        /// <param name="body">Required parameter: Parameters to extend the duration of an active session.</param>
        /// <param name="xCorrelator">Optional parameter: Correlation id for the different services.</param>
        /// <returns>Returns the Models.SessionInfo response from the API call.</returns>
        public Models.SessionInfo ExtendQosSessionDuration(
                Guid sessionId,
                Models.ExtendSessionDuration body,
                string xCorrelator = null)
            => CoreHelper.RunTask(ExtendQosSessionDurationAsync(sessionId, body, xCorrelator));

        /// <summary>
        /// Extend the overall session duration of an active QoS session (with qosStatus = AVAILABLE).
        /// The overall duration of the QoS session, including the additional extended duration, shall not exceed the maximum duration limit fixed for the QoS Profile. If the current duration plus the value of `requestedAdditionalDuration` exceeds the maximum limit, the new overall duration shall be capped to the maximum value allowed.
        /// An example: For a QoS profile limited to a `maxDuration` of 50,000 seconds, a QoD session was originally created with duration 30,000 seconds. Before the session expires, the developer requests to extend the session by another 30,000 seconds:.
        /// - Previous duration: 30,000 seconds.
        /// - Requested additional duration: 30,000 seconds.
        /// - New overall session duration: 50,000 seconds (the maximum allowed).
        /// **NOTES:**.
        /// - The access token may be either 2-legged or 3-legged.
        /// - If a 3-legged access token is used, the subject associated with the session must also be associated with the access token.
        /// - The session must must have been created by the same API consumer given in the access token.
        /// </summary>
        /// <param name="sessionId">Required parameter: Session ID that was obtained from the createSession operation.</param>
        /// <param name="body">Required parameter: Parameters to extend the duration of an active session.</param>
        /// <param name="xCorrelator">Optional parameter: Correlation id for the different services.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.SessionInfo response from the API call.</returns>
        public async Task<Models.SessionInfo> ExtendQosSessionDurationAsync(
                Guid sessionId,
                Models.ExtendSessionDuration body,
                string xCorrelator = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.SessionInfo>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/sessions/{sessionId}/extend")
                  .WithAuth("openId")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(body))
                      .Template(_template => _template.Setup("sessionId", sessionId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Header(_header => _header.Setup("x-correlator", xCorrelator))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("Bad Request", (_reason, _context) => new GenericExtendSessionDuration400Exception(_reason, _context)))
                  .ErrorCase("401", CreateErrorCase("Unauthorized", (_reason, _context) => new Generic401Exception(_reason, _context)))
                  .ErrorCase("403", CreateErrorCase("Forbidden", (_reason, _context) => new Generic401Exception(_reason, _context)))
                  .ErrorCase("404", CreateErrorCase("Not found", (_reason, _context) => new Generic401Exception(_reason, _context)))
                  .ErrorCase("409", CreateErrorCase("Conflict", (_reason, _context) => new SessionStatusConflict409Exception(_reason, _context)))
                  .ErrorCase("429", CreateErrorCase("Too Many Requests", (_reason, _context) => new Generic429Exception(_reason, _context))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// Querying for QoS session resource information details for a device.
        /// **NOTES:**.
        /// - The access token may be either 2-legged or 3-legged.
        ///   - If a 3-legged access token is used, the subject associated with the session must also be associated with the access token. In this case the optional `device` parameter MUST NOT be provided in the request.
        ///   - If a 2-legged access token is used, the device parameter must be provided and identify a device.
        /// - The session must have been created by the same API consumer given in the access token.
        /// - If no QoS session is found for the requested device, an empty array is returned.
        /// - This call uses the POST method instead of GET to comply with the CAMARA Commonalities guidelines for sending sensitive or complex data in API calls. Since the device field may contain personally identifiable information, it should not be sent via GET.
        ///   [CAMARA API Design Guidelines](https://github.com/camaraproject/Commonalities/blob/r2.3/documentation/API-design-guidelines.md#post-or-get-for-transferring-sensitive-or-complex-data).
        /// </summary>
        /// <param name="body">Required parameter: Parameters to get QoS session information by device.</param>
        /// <param name="xCorrelator">Optional parameter: Correlation id for the different services.</param>
        /// <returns>Returns the List of Models.SessionInfo response from the API call.</returns>
        public List<Models.SessionInfo> RetrieveSessionsByDevice(
                Models.RetrieveSessionsInput body,
                string xCorrelator = null)
            => CoreHelper.RunTask(RetrieveSessionsByDeviceAsync(body, xCorrelator));

        /// <summary>
        /// Querying for QoS session resource information details for a device.
        /// **NOTES:**.
        /// - The access token may be either 2-legged or 3-legged.
        ///   - If a 3-legged access token is used, the subject associated with the session must also be associated with the access token. In this case the optional `device` parameter MUST NOT be provided in the request.
        ///   - If a 2-legged access token is used, the device parameter must be provided and identify a device.
        /// - The session must have been created by the same API consumer given in the access token.
        /// - If no QoS session is found for the requested device, an empty array is returned.
        /// - This call uses the POST method instead of GET to comply with the CAMARA Commonalities guidelines for sending sensitive or complex data in API calls. Since the device field may contain personally identifiable information, it should not be sent via GET.
        ///   [CAMARA API Design Guidelines](https://github.com/camaraproject/Commonalities/blob/r2.3/documentation/API-design-guidelines.md#post-or-get-for-transferring-sensitive-or-complex-data).
        /// </summary>
        /// <param name="body">Required parameter: Parameters to get QoS session information by device.</param>
        /// <param name="xCorrelator">Optional parameter: Correlation id for the different services.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the List of Models.SessionInfo response from the API call.</returns>
        public async Task<List<Models.SessionInfo>> RetrieveSessionsByDeviceAsync(
                Models.RetrieveSessionsInput body,
                string xCorrelator = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<List<Models.SessionInfo>>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/retrieve-sessions")
                  .WithAuth("openId")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(body))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Header(_header => _header.Setup("x-correlator", xCorrelator))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("Bad Request", (_reason, _context) => new Generic400Exception(_reason, _context)))
                  .ErrorCase("401", CreateErrorCase("Unauthorized", (_reason, _context) => new Generic401Exception(_reason, _context)))
                  .ErrorCase("403", CreateErrorCase("Forbidden", (_reason, _context) => new Generic401Exception(_reason, _context)))
                  .ErrorCase("404", CreateErrorCase("Not found", (_reason, _context) => new GenericDevice404Exception(_reason, _context)))
                  .ErrorCase("422", CreateErrorCase("Unprocessable Content", (_reason, _context) => new Generic422Exception(_reason, _context)))
                  .ErrorCase("429", CreateErrorCase("Too Many Requests", (_reason, _context) => new Generic429Exception(_reason, _context))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);
    }
}