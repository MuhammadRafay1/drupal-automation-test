// <copyright file="PlainCredential.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using JsonSubTypes;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using QualityOnDemand.Standard;
using QualityOnDemand.Standard.Utilities;

namespace QualityOnDemand.Standard.Models
{
    /// <summary>
    /// PlainCredential.
    /// </summary>
    public class PlainCredential : SinkCredential
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PlainCredential"/> class.
        /// </summary>
        public PlainCredential()
        {
            this.CredentialType = "PLAIN";
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PlainCredential"/> class.
        /// </summary>
        /// <param name="identifier">identifier.</param>
        /// <param name="secret">secret.</param>
        /// <param name="credentialType">credentialType.</param>
        public PlainCredential(
            string identifier,
            string secret,
            string credentialType = "PLAIN")
            : base(
                credentialType)
        {
            this.Identifier = identifier;
            this.Secret = secret;
        }

        /// <summary>
        /// The identifier might be an account or username.
        /// </summary>
        [JsonProperty("identifier")]
        public string Identifier { get; set; }

        /// <summary>
        /// The secret might be a password or passphrase.
        /// </summary>
        [JsonProperty("secret")]
        public string Secret { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();
            this.ToString(toStringOutput);
            return $"PlainCredential : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj is null) return false;
            if (ReferenceEquals(this, obj)) return true;

            return obj is PlainCredential other &&
                (this.Identifier == null && other.Identifier == null ||
                 this.Identifier?.Equals(other.Identifier) == true) &&
                (this.Secret == null && other.Secret == null ||
                 this.Secret?.Equals(other.Secret) == true) &&
                base.Equals(obj);
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected new void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"Identifier = {this.Identifier ?? "null"}");
            toStringOutput.Add($"Secret = {this.Secret ?? "null"}");

            base.ToString(toStringOutput);
        }
    }
}