// <copyright file="ExtendSessionDuration.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using JsonSubTypes;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using QualityOnDemand.Standard;
using QualityOnDemand.Standard.Utilities;

namespace QualityOnDemand.Standard.Models
{
    /// <summary>
    /// ExtendSessionDuration.
    /// </summary>
    public class ExtendSessionDuration
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ExtendSessionDuration"/> class.
        /// </summary>
        public ExtendSessionDuration()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ExtendSessionDuration"/> class.
        /// </summary>
        /// <param name="requestedAdditionalDuration">requestedAdditionalDuration.</param>
        public ExtendSessionDuration(
            int requestedAdditionalDuration)
        {
            this.RequestedAdditionalDuration = requestedAdditionalDuration;
        }

        /// <summary>
        /// Additional duration in seconds to be added to the current session duration. The overall session duration, including extensions, shall not exceed the maximum duration limit for the QoS Profile.
        /// </summary>
        [JsonProperty("requestedAdditionalDuration")]
        public int RequestedAdditionalDuration { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();
            this.ToString(toStringOutput);
            return $"ExtendSessionDuration : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj is null) return false;
            if (ReferenceEquals(this, obj)) return true;

            return obj is ExtendSessionDuration other &&
                (this.RequestedAdditionalDuration.Equals(other.RequestedAdditionalDuration));
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"RequestedAdditionalDuration = {this.RequestedAdditionalDuration}");
        }
    }
}