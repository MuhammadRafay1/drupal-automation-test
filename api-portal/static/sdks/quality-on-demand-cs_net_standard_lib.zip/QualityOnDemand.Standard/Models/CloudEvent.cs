// <copyright file="CloudEvent.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using JsonSubTypes;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using QualityOnDemand.Standard;
using QualityOnDemand.Standard.Utilities;

namespace QualityOnDemand.Standard.Models
{
    /// <summary>
    /// CloudEvent.
    /// </summary>
    [JsonConverter(typeof(JsonSubtypes), "type")]
    [JsonSubtypes.KnownSubType(typeof(EventQosStatusChanged), "org.camaraproject.quality-on-demand.v1.qos-status-changed")]
    public class CloudEvent
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CloudEvent"/> class.
        /// </summary>
        public CloudEvent()
        {
            this.Type = "CloudEvent";
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CloudEvent"/> class.
        /// </summary>
        /// <param name="id">id.</param>
        /// <param name="source">source.</param>
        /// <param name="specversion">specversion.</param>
        /// <param name="time">time.</param>
        /// <param name="type">type.</param>
        /// <param name="datacontenttype">datacontenttype.</param>
        /// <param name="data">data.</param>
        public CloudEvent(
            string id,
            string source,
            string specversion,
            DateTime time,
            string type = "CloudEvent",
            Models.DatacontenttypeEnum? datacontenttype = null,
            object data = null)
        {
            this.Id = id;
            this.Source = source;
            this.Type = type;
            this.Specversion = specversion;
            this.Datacontenttype = datacontenttype;
            this.Data = data;
            this.Time = time;
        }

        /// <summary>
        /// Identifier of this event, that must be unique in the source context.
        /// </summary>
        [JsonProperty("id")]
        public string Id { get; set; }

        /// <summary>
        /// Identifies the context in which an event happened in the specific provider implementation.
        /// </summary>
        [JsonProperty("source")]
        public string Source { get; set; }

        /// <summary>
        /// Gets or sets Type.
        /// </summary>
        [JsonProperty("type", NullValueHandling = NullValueHandling.Ignore)]
        public string Type { get; set; }

        /// <summary>
        /// Version of the specification to which this event conforms (must be 1.0 if it conforms to Cloudevents 1.0.2 version)
        /// </summary>
        [JsonProperty("specversion")]
        public string Specversion { get; set; }

        /// <summary>
        /// media-type that describes the event payload encoding, must be "application/json" for CAMARA APIs
        /// </summary>
        [JsonProperty("datacontenttype", NullValueHandling = NullValueHandling.Ignore)]
        public Models.DatacontenttypeEnum? Datacontenttype { get; set; }

        /// <summary>
        /// Event notification details payload, which depends on the event type
        /// </summary>
        [JsonProperty("data", NullValueHandling = NullValueHandling.Ignore)]
        public object Data { get; set; }

        /// <summary>
        /// Timestamp of when the occurrence happened. It must follow RFC 3339
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("time")]
        public DateTime Time { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();
            this.ToString(toStringOutput);
            return $"CloudEvent : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj is null) return false;
            if (ReferenceEquals(this, obj)) return true;

            return obj is CloudEvent other &&
                (this.Id == null && other.Id == null ||
                 this.Id?.Equals(other.Id) == true) &&
                (this.Source == null && other.Source == null ||
                 this.Source?.Equals(other.Source) == true) &&
                (this.Type == null && other.Type == null ||
                 this.Type?.Equals(other.Type) == true) &&
                (this.Specversion == null && other.Specversion == null ||
                 this.Specversion?.Equals(other.Specversion) == true) &&
                (this.Datacontenttype == null && other.Datacontenttype == null ||
                 this.Datacontenttype?.Equals(other.Datacontenttype) == true) &&
                (this.Data == null && other.Data == null ||
                 this.Data?.Equals(other.Data) == true) &&
                (this.Time.Equals(other.Time));
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"Id = {this.Id ?? "null"}");
            toStringOutput.Add($"Source = {this.Source ?? "null"}");
            toStringOutput.Add($"Type = {this.Type ?? "null"}");
            toStringOutput.Add($"Specversion = {this.Specversion ?? "null"}");
            toStringOutput.Add($"Datacontenttype = {(this.Datacontenttype == null ? "null" : this.Datacontenttype.ToString())}");
            toStringOutput.Add($"Data = {(this.Data == null ? "null" : this.Data.ToString())}");
            toStringOutput.Add($"Time = {this.Time}");
        }
    }
}