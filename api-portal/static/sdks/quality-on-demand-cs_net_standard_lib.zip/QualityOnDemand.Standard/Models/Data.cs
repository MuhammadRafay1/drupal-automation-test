// <copyright file="Data.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using JsonSubTypes;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using QualityOnDemand.Standard;
using QualityOnDemand.Standard.Utilities;

namespace QualityOnDemand.Standard.Models
{
    /// <summary>
    /// Data.
    /// </summary>
    public class Data
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Data"/> class.
        /// </summary>
        public Data()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Data"/> class.
        /// </summary>
        /// <param name="sessionId">sessionId.</param>
        /// <param name="qosStatus">qosStatus.</param>
        /// <param name="statusInfo">statusInfo.</param>
        public Data(
            Guid sessionId,
            Models.EventQosStatusEnum qosStatus,
            Models.StatusInfoEnum? statusInfo = null)
        {
            this.SessionId = sessionId;
            this.QosStatus = qosStatus;
            this.StatusInfo = statusInfo;
        }

        /// <summary>
        /// Session ID in UUID format
        /// </summary>
        [JsonProperty("sessionId")]
        public Guid SessionId { get; set; }

        /// <summary>
        /// The current status of a requested or previously available session. Applicable values in the event are:
        /// *  `AVAILABLE` - The requested QoS has been provided by the network.
        /// *  `UNAVAILABLE` - A requested or previously available QoS session is now unavailable. `statusInfo` may provide additional information about the reason for the unavailability.
        /// </summary>
        [JsonProperty("qosStatus")]
        public Models.EventQosStatusEnum QosStatus { get; set; }

        /// <summary>
        /// Reason for the new `qosStatus`. Currently `statusInfo` is only applicable when `qosStatus` is 'UNAVAILABLE'.
        /// * `DURATION_EXPIRED` - Session terminated due to requested duration expired
        /// * `NETWORK_TERMINATED` - Network terminated the session before the requested duration expired
        /// * `DELETE_REQUESTED`- User requested the deletion of the session before the requested duration expired
        /// </summary>
        [JsonProperty("statusInfo", NullValueHandling = NullValueHandling.Ignore)]
        public Models.StatusInfoEnum? StatusInfo { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();
            this.ToString(toStringOutput);
            return $"Data : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj is null) return false;
            if (ReferenceEquals(this, obj)) return true;

            return obj is Data other &&
                (this.SessionId.Equals(other.SessionId)) &&
                (this.QosStatus.Equals(other.QosStatus)) &&
                (this.StatusInfo == null && other.StatusInfo == null ||
                 this.StatusInfo?.Equals(other.StatusInfo) == true);
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"SessionId = {this.SessionId}");
            toStringOutput.Add($"QosStatus = {this.QosStatus}");
            toStringOutput.Add($"StatusInfo = {(this.StatusInfo == null ? "null" : this.StatusInfo.ToString())}");
        }
    }
}