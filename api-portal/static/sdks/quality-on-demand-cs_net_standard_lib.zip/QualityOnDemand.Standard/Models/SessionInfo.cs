// <copyright file="SessionInfo.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using JsonSubTypes;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using QualityOnDemand.Standard;
using QualityOnDemand.Standard.Utilities;

namespace QualityOnDemand.Standard.Models
{
    /// <summary>
    /// SessionInfo.
    /// </summary>
    public class SessionInfo
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="SessionInfo"/> class.
        /// </summary>
        public SessionInfo()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="SessionInfo"/> class.
        /// </summary>
        /// <param name="applicationServer">applicationServer.</param>
        /// <param name="qosProfile">qosProfile.</param>
        /// <param name="sessionId">sessionId.</param>
        /// <param name="duration">duration.</param>
        /// <param name="qosStatus">qosStatus.</param>
        /// <param name="device">device.</param>
        /// <param name="devicePorts">devicePorts.</param>
        /// <param name="applicationServerPorts">applicationServerPorts.</param>
        /// <param name="sink">sink.</param>
        /// <param name="sinkCredential">sinkCredential.</param>
        /// <param name="startedAt">startedAt.</param>
        /// <param name="expiresAt">expiresAt.</param>
        /// <param name="statusInfo">statusInfo.</param>
        public SessionInfo(
            Models.ApplicationServer applicationServer,
            string qosProfile,
            Guid sessionId,
            int duration,
            Models.QosStatusEnum qosStatus,
            Models.Device device = null,
            Models.PortsSpec devicePorts = null,
            Models.PortsSpec applicationServerPorts = null,
            string sink = null,
            Models.SinkCredential sinkCredential = null,
            DateTime? startedAt = null,
            DateTime? expiresAt = null,
            Models.StatusInfoEnum? statusInfo = null)
        {
            this.Device = device;
            this.ApplicationServer = applicationServer;
            this.DevicePorts = devicePorts;
            this.ApplicationServerPorts = applicationServerPorts;
            this.QosProfile = qosProfile;
            this.Sink = sink;
            this.SinkCredential = sinkCredential;
            this.SessionId = sessionId;
            this.Duration = duration;
            this.StartedAt = startedAt;
            this.ExpiresAt = expiresAt;
            this.QosStatus = qosStatus;
            this.StatusInfo = statusInfo;
        }

        /// <summary>
        /// End-user equipment able to connect to a network. Examples of devices include smartphones or IoT sensors/actuators.
        /// The developer can choose to provide the below specified device identifiers:
        /// * `ipv4Address`
        /// * `ipv6Address`
        /// * `phoneNumber`
        /// * `networkAccessIdentifier`
        /// NOTE1: the network operator might support only a subset of these options. The API consumer can provide multiple identifiers to be compatible across different network operators. In this case the identifiers MUST belong to the same device.
        /// NOTE2: as for this Commonalities release, we are enforcing that the networkAccessIdentifier is only part of the schema for future-proofing, and CAMARA does not currently allow its use. After the CAMARA meta-release work is concluded and the relevant issues are resolved, its use will need to be explicitly documented in the guidelines.
        /// </summary>
        [JsonProperty("device", NullValueHandling = NullValueHandling.Ignore)]
        public Models.Device Device { get; set; }

        /// <summary>
        /// A server hosting backend applications to deliver some business logic to clients.
        /// The developer can choose to provide the below specified device identifiers:
        /// * `ipv4Address`
        /// * `ipv6Address`
        /// </summary>
        [JsonProperty("applicationServer")]
        public Models.ApplicationServer ApplicationServer { get; set; }

        /// <summary>
        /// The ports used locally by the device for flows to which the requested QoS profile should apply. If omitted, then the qosProfile will apply to all flows between the device and the specified application server address and ports
        /// </summary>
        [JsonProperty("devicePorts", NullValueHandling = NullValueHandling.Ignore)]
        public Models.PortsSpec DevicePorts { get; set; }

        /// <summary>
        /// A list of single ports or port ranges on the application server
        /// </summary>
        [JsonProperty("applicationServerPorts", NullValueHandling = NullValueHandling.Ignore)]
        public Models.PortsSpec ApplicationServerPorts { get; set; }

        /// <summary>
        /// A unique name for identifying a specific QoS profile.
        /// This may follow different formats depending on the API provider implementation.
        /// Some options addresses:
        ///   - A UUID style string
        ///   - Support for predefined profiles QOS_S, QOS_M, QOS_L, and QOS_E
        ///   - A searchable descriptive name
        /// The set of QoS Profiles that an API provider is offering may be retrieved by means of the QoS Profile API (qos-profile) or agreed on onboarding time.
        /// </summary>
        [JsonProperty("qosProfile")]
        public string QosProfile { get; set; }

        /// <summary>
        /// The address to which events about all status changes of the session (e.g. session termination) shall be delivered using the selected protocol.
        /// </summary>
        [JsonProperty("sink", NullValueHandling = NullValueHandling.Ignore)]
        public string Sink { get; set; }

        /// <summary>
        /// A sink credential provides authentication or authorization information necessary to enable delivery of events to a target.
        /// </summary>
        [JsonProperty("sinkCredential", NullValueHandling = NullValueHandling.Ignore)]
        public Models.SinkCredential SinkCredential { get; set; }

        /// <summary>
        /// Session ID in UUID format
        /// </summary>
        [JsonProperty("sessionId")]
        public Guid SessionId { get; set; }

        /// <summary>
        /// Session duration in seconds. Implementations can grant the requested session duration or set a different duration, based on network policies or conditions.
        /// - When `qosStatus` is "REQUESTED", the value is the duration to be scheduled, granted by the implementation.
        /// - When `qosStatus` is AVAILABLE", the value is the overall duration since `startedAt. When the session is extended, the value is the new overall duration of the session.
        /// - When `qosStatus` is "UNAVAILABLE", the value is the overall effective duration since `startedAt` until the session was terminated.
        /// </summary>
        [JsonProperty("duration")]
        public int Duration { get; set; }

        /// <summary>
        /// Date and time when the QoS status became "AVAILABLE". Not to be returned when `qosStatus` is "REQUESTED". Format must follow RFC 3339 and must indicate time zone (UTC or local).
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("startedAt", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? StartedAt { get; set; }

        /// <summary>
        /// Date and time of the QoS session expiration. Format must follow RFC 3339 and must indicate time zone (UTC or local).
        /// - When `qosStatus` is "AVAILABLE", it is the limit time when the session is scheduled to finnish, if not terminated by other means.
        /// - When `qosStatus` is "UNAVAILABLE", it is the time when the session was terminated.
        /// - Not to be returned when `qosStatus` is "REQUESTED".
        /// When the session is extended, the value is the new expiration time of the session.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("expiresAt", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? ExpiresAt { get; set; }

        /// <summary>
        /// The current status of the requested QoS session. The status can be one of the following:
        /// * `REQUESTED` - QoS has been requested by creating a session
        /// * `AVAILABLE` - The requested QoS has been provided by the network
        /// * `UNAVAILABLE` - The requested QoS cannot be provided by the network due to some reason
        /// </summary>
        [JsonProperty("qosStatus")]
        public Models.QosStatusEnum QosStatus { get; set; }

        /// <summary>
        /// Reason for the new `qosStatus`. Currently `statusInfo` is only applicable when `qosStatus` is 'UNAVAILABLE'.
        /// * `DURATION_EXPIRED` - Session terminated due to requested duration expired
        /// * `NETWORK_TERMINATED` - Network terminated the session before the requested duration expired
        /// * `DELETE_REQUESTED`- User requested the deletion of the session before the requested duration expired
        /// </summary>
        [JsonProperty("statusInfo", NullValueHandling = NullValueHandling.Ignore)]
        public Models.StatusInfoEnum? StatusInfo { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();
            this.ToString(toStringOutput);
            return $"SessionInfo : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj is null) return false;
            if (ReferenceEquals(this, obj)) return true;

            return obj is SessionInfo other &&
                (this.Device == null && other.Device == null ||
                 this.Device?.Equals(other.Device) == true) &&
                (this.ApplicationServer == null && other.ApplicationServer == null ||
                 this.ApplicationServer?.Equals(other.ApplicationServer) == true) &&
                (this.DevicePorts == null && other.DevicePorts == null ||
                 this.DevicePorts?.Equals(other.DevicePorts) == true) &&
                (this.ApplicationServerPorts == null && other.ApplicationServerPorts == null ||
                 this.ApplicationServerPorts?.Equals(other.ApplicationServerPorts) == true) &&
                (this.QosProfile == null && other.QosProfile == null ||
                 this.QosProfile?.Equals(other.QosProfile) == true) &&
                (this.Sink == null && other.Sink == null ||
                 this.Sink?.Equals(other.Sink) == true) &&
                (this.SinkCredential == null && other.SinkCredential == null ||
                 this.SinkCredential?.Equals(other.SinkCredential) == true) &&
                (this.SessionId.Equals(other.SessionId)) &&
                (this.Duration.Equals(other.Duration)) &&
                (this.StartedAt == null && other.StartedAt == null ||
                 this.StartedAt?.Equals(other.StartedAt) == true) &&
                (this.ExpiresAt == null && other.ExpiresAt == null ||
                 this.ExpiresAt?.Equals(other.ExpiresAt) == true) &&
                (this.QosStatus.Equals(other.QosStatus)) &&
                (this.StatusInfo == null && other.StatusInfo == null ||
                 this.StatusInfo?.Equals(other.StatusInfo) == true);
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"Device = {(this.Device == null ? "null" : this.Device.ToString())}");
            toStringOutput.Add($"ApplicationServer = {(this.ApplicationServer == null ? "null" : this.ApplicationServer.ToString())}");
            toStringOutput.Add($"DevicePorts = {(this.DevicePorts == null ? "null" : this.DevicePorts.ToString())}");
            toStringOutput.Add($"ApplicationServerPorts = {(this.ApplicationServerPorts == null ? "null" : this.ApplicationServerPorts.ToString())}");
            toStringOutput.Add($"QosProfile = {this.QosProfile ?? "null"}");
            toStringOutput.Add($"Sink = {this.Sink ?? "null"}");
            toStringOutput.Add($"SinkCredential = {(this.SinkCredential == null ? "null" : this.SinkCredential.ToString())}");
            toStringOutput.Add($"SessionId = {this.SessionId}");
            toStringOutput.Add($"Duration = {this.Duration}");
            toStringOutput.Add($"StartedAt = {(this.StartedAt == null ? "null" : this.StartedAt.ToString())}");
            toStringOutput.Add($"ExpiresAt = {(this.ExpiresAt == null ? "null" : this.ExpiresAt.ToString())}");
            toStringOutput.Add($"QosStatus = {this.QosStatus}");
            toStringOutput.Add($"StatusInfo = {(this.StatusInfo == null ? "null" : this.StatusInfo.ToString())}");
        }
    }
}