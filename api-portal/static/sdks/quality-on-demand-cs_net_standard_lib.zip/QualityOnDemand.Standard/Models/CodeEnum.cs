// <copyright file="CodeEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using APIMatic.Core.Utilities.Converters;
using Newtonsoft.Json;
using QualityOnDemand.Standard;
using QualityOnDemand.Standard.Utilities;

namespace QualityOnDemand.Standard.Models
{
    /// <summary>
    /// CodeEnum.
    /// </summary>

    [JsonConverter(typeof(StringEnumConverter))]
    public enum CodeEnum
    {
        /// <summary>
        /// INVALIDARGUMENT.
        /// </summary>
        [EnumMember(Value = "INVALID_ARGUMENT")]
        INVALIDARGUMENT,

        /// <summary>
        /// OUTOFRANGE.
        /// </summary>
        [EnumMember(Value = "OUT_OF_RANGE")]
        OUTOFRANGE,

        /// <summary>
        /// EnumQUALITYONDEMANDDURATIONOUTOFRANGE.
        /// </summary>
        [EnumMember(Value = "QUALITY_ON_DEMAND.DURATION_OUT_OF_RANGE")]
        EnumQUALITYONDEMANDDURATIONOUTOFRANGE,

        /// <summary>
        /// INVALIDCREDENTIAL.
        /// </summary>
        [EnumMember(Value = "INVALID_CREDENTIAL")]
        INVALIDCREDENTIAL,

        /// <summary>
        /// INVALIDTOKEN.
        /// </summary>
        [EnumMember(Value = "INVALID_TOKEN")]
        INVALIDTOKEN
    }
}