// <copyright file="RefreshTokenCredential.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using JsonSubTypes;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using QualityOnDemand.Standard;
using QualityOnDemand.Standard.Utilities;

namespace QualityOnDemand.Standard.Models
{
    /// <summary>
    /// RefreshTokenCredential.
    /// </summary>
    public class RefreshTokenCredential : SinkCredential
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="RefreshTokenCredential"/> class.
        /// </summary>
        public RefreshTokenCredential()
        {
            this.CredentialType = "REFRESHTOKEN";
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="RefreshTokenCredential"/> class.
        /// </summary>
        /// <param name="accessToken">accessToken.</param>
        /// <param name="accessTokenExpiresUtc">accessTokenExpiresUtc.</param>
        /// <param name="accessTokenType">accessTokenType.</param>
        /// <param name="refreshToken">refreshToken.</param>
        /// <param name="refreshTokenEndpoint">refreshTokenEndpoint.</param>
        /// <param name="credentialType">credentialType.</param>
        public RefreshTokenCredential(
            string accessToken,
            DateTime accessTokenExpiresUtc,
            string accessTokenType,
            string refreshToken,
            string refreshTokenEndpoint,
            string credentialType = "REFRESHTOKEN")
            : base(
                credentialType)
        {
            this.AccessToken = accessToken;
            this.AccessTokenExpiresUtc = accessTokenExpiresUtc;
            this.AccessTokenType = accessTokenType;
            this.RefreshToken = refreshToken;
            this.RefreshTokenEndpoint = refreshTokenEndpoint;
        }

        /// <summary>
        /// REQUIRED. An access token is a previously acquired token granting access to the target resource.
        /// </summary>
        [JsonProperty("accessToken")]
        public string AccessToken { get; set; }

        /// <summary>
        /// REQUIRED. An absolute UTC instant at which the token shall be considered expired.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("accessTokenExpiresUtc")]
        public DateTime AccessTokenExpiresUtc { get; set; }

        /// <summary>
        /// REQUIRED. Type of the access token (See [OAuth 2.0](https://tools.ietf.org/html/rfc6749#section-7.1)).
        /// </summary>
        [JsonProperty("accessTokenType")]
        public string AccessTokenType { get; set; }

        /// <summary>
        /// REQUIRED. An refresh token credential used to acquire access tokens.
        /// </summary>
        [JsonProperty("refreshToken")]
        public string RefreshToken { get; set; }

        /// <summary>
        /// REQUIRED. A URL at which the refresh token can be traded for an access token.
        /// </summary>
        [JsonProperty("refreshTokenEndpoint")]
        public string RefreshTokenEndpoint { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();
            this.ToString(toStringOutput);
            return $"RefreshTokenCredential : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj is null) return false;
            if (ReferenceEquals(this, obj)) return true;

            return obj is RefreshTokenCredential other &&
                (this.AccessToken == null && other.AccessToken == null ||
                 this.AccessToken?.Equals(other.AccessToken) == true) &&
                (this.AccessTokenExpiresUtc.Equals(other.AccessTokenExpiresUtc)) &&
                (this.AccessTokenType == null && other.AccessTokenType == null ||
                 this.AccessTokenType?.Equals(other.AccessTokenType) == true) &&
                (this.RefreshToken == null && other.RefreshToken == null ||
                 this.RefreshToken?.Equals(other.RefreshToken) == true) &&
                (this.RefreshTokenEndpoint == null && other.RefreshTokenEndpoint == null ||
                 this.RefreshTokenEndpoint?.Equals(other.RefreshTokenEndpoint) == true) &&
                base.Equals(obj);
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected new void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"AccessToken = {this.AccessToken ?? "null"}");
            toStringOutput.Add($"AccessTokenExpiresUtc = {this.AccessTokenExpiresUtc}");
            toStringOutput.Add($"AccessTokenType = {this.AccessTokenType ?? "null"}");
            toStringOutput.Add($"RefreshToken = {this.RefreshToken ?? "null"}");
            toStringOutput.Add($"RefreshTokenEndpoint = {this.RefreshTokenEndpoint ?? "null"}");

            base.ToString(toStringOutput);
        }
    }
}