// <copyright file="Code4Enum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using APIMatic.Core.Utilities.Converters;
using Newtonsoft.Json;
using QualityOnDemand.Standard;
using QualityOnDemand.Standard.Utilities;

namespace QualityOnDemand.Standard.Models
{
    /// <summary>
    /// Code4Enum.
    /// </summary>

    [JsonConverter(typeof(StringEnumConverter))]
    public enum Code4Enum
    {
        /// <summary>
        /// INVALIDARGUMENT.
        /// </summary>
        [EnumMember(Value = "INVALID_ARGUMENT")]
        INVALIDARGUMENT,

        /// <summary>
        /// OUTOFRANGE.
        /// </summary>
        [EnumMember(Value = "OUT_OF_RANGE")]
        OUTOFRANGE
    }
}