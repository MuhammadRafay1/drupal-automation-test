// <copyright file="Code5Enum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using APIMatic.Core.Utilities.Converters;
using Newtonsoft.Json;
using QualityOnDemand.Standard;
using QualityOnDemand.Standard.Utilities;

namespace QualityOnDemand.Standard.Models
{
    /// <summary>
    /// Code5Enum.
    /// </summary>

    [JsonConverter(typeof(StringEnumConverter))]
    public enum Code5Enum
    {
        /// <summary>
        /// INVALIDARGUMENT.
        /// </summary>
        [EnumMember(Value = "INVALID_ARGUMENT")]
        INVALIDARGUMENT,

        /// <summary>
        /// OUTOFRANGE.
        /// </summary>
        [EnumMember(Value = "OUT_OF_RANGE")]
        OUTOFRANGE,

        /// <summary>
        /// EnumQUALITYONDEMANDDURATIONOUTOFRANGE.
        /// </summary>
        [EnumMember(Value = "QUALITY_ON_DEMAND.DURATION_OUT_OF_RANGE")]
        EnumQUALITYONDEMANDDURATIONOUTOFRANGE
    }
}