// <copyright file="CreateSession.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using JsonSubTypes;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using QualityOnDemand.Standard;
using QualityOnDemand.Standard.Utilities;

namespace QualityOnDemand.Standard.Models
{
    /// <summary>
    /// CreateSession.
    /// </summary>
    public class CreateSession
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CreateSession"/> class.
        /// </summary>
        public CreateSession()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CreateSession"/> class.
        /// </summary>
        /// <param name="applicationServer">applicationServer.</param>
        /// <param name="qosProfile">qosProfile.</param>
        /// <param name="duration">duration.</param>
        /// <param name="device">device.</param>
        /// <param name="devicePorts">devicePorts.</param>
        /// <param name="applicationServerPorts">applicationServerPorts.</param>
        /// <param name="sink">sink.</param>
        /// <param name="sinkCredential">sinkCredential.</param>
        public CreateSession(
            Models.ApplicationServer applicationServer,
            string qosProfile,
            int duration,
            Models.Device device = null,
            Models.PortsSpec devicePorts = null,
            Models.PortsSpec applicationServerPorts = null,
            string sink = null,
            Models.SinkCredential sinkCredential = null)
        {
            this.Device = device;
            this.ApplicationServer = applicationServer;
            this.DevicePorts = devicePorts;
            this.ApplicationServerPorts = applicationServerPorts;
            this.QosProfile = qosProfile;
            this.Sink = sink;
            this.SinkCredential = sinkCredential;
            this.Duration = duration;
        }

        /// <summary>
        /// End-user equipment able to connect to a network. Examples of devices include smartphones or IoT sensors/actuators.
        /// The developer can choose to provide the below specified device identifiers:
        /// * `ipv4Address`
        /// * `ipv6Address`
        /// * `phoneNumber`
        /// * `networkAccessIdentifier`
        /// NOTE1: the network operator might support only a subset of these options. The API consumer can provide multiple identifiers to be compatible across different network operators. In this case the identifiers MUST belong to the same device.
        /// NOTE2: as for this Commonalities release, we are enforcing that the networkAccessIdentifier is only part of the schema for future-proofing, and CAMARA does not currently allow its use. After the CAMARA meta-release work is concluded and the relevant issues are resolved, its use will need to be explicitly documented in the guidelines.
        /// </summary>
        [JsonProperty("device", NullValueHandling = NullValueHandling.Ignore)]
        public Models.Device Device { get; set; }

        /// <summary>
        /// A server hosting backend applications to deliver some business logic to clients.
        /// The developer can choose to provide the below specified device identifiers:
        /// * `ipv4Address`
        /// * `ipv6Address`
        /// </summary>
        [JsonProperty("applicationServer")]
        public Models.ApplicationServer ApplicationServer { get; set; }

        /// <summary>
        /// The ports used locally by the device for flows to which the requested QoS profile should apply. If omitted, then the qosProfile will apply to all flows between the device and the specified application server address and ports
        /// </summary>
        [JsonProperty("devicePorts", NullValueHandling = NullValueHandling.Ignore)]
        public Models.PortsSpec DevicePorts { get; set; }

        /// <summary>
        /// A list of single ports or port ranges on the application server
        /// </summary>
        [JsonProperty("applicationServerPorts", NullValueHandling = NullValueHandling.Ignore)]
        public Models.PortsSpec ApplicationServerPorts { get; set; }

        /// <summary>
        /// A unique name for identifying a specific QoS profile.
        /// This may follow different formats depending on the API provider implementation.
        /// Some options addresses:
        ///   - A UUID style string
        ///   - Support for predefined profiles QOS_S, QOS_M, QOS_L, and QOS_E
        ///   - A searchable descriptive name
        /// The set of QoS Profiles that an API provider is offering may be retrieved by means of the QoS Profile API (qos-profile) or agreed on onboarding time.
        /// </summary>
        [JsonProperty("qosProfile")]
        public string QosProfile { get; set; }

        /// <summary>
        /// The address to which events about all status changes of the session (e.g. session termination) shall be delivered using the selected protocol.
        /// </summary>
        [JsonProperty("sink", NullValueHandling = NullValueHandling.Ignore)]
        public string Sink { get; set; }

        /// <summary>
        /// A sink credential provides authentication or authorization information necessary to enable delivery of events to a target.
        /// </summary>
        [JsonProperty("sinkCredential", NullValueHandling = NullValueHandling.Ignore)]
        public Models.SinkCredential SinkCredential { get; set; }

        /// <summary>
        /// Requested session duration in seconds. Value may be explicitly limited for the QoS profile, as specified in the Qos Profile (see qos-profile API). Implementations can grant the requested session duration or set a different duration, based on network policies or conditions.
        /// </summary>
        [JsonProperty("duration")]
        public int Duration { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();
            this.ToString(toStringOutput);
            return $"CreateSession : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj is null) return false;
            if (ReferenceEquals(this, obj)) return true;

            return obj is CreateSession other &&
                (this.Device == null && other.Device == null ||
                 this.Device?.Equals(other.Device) == true) &&
                (this.ApplicationServer == null && other.ApplicationServer == null ||
                 this.ApplicationServer?.Equals(other.ApplicationServer) == true) &&
                (this.DevicePorts == null && other.DevicePorts == null ||
                 this.DevicePorts?.Equals(other.DevicePorts) == true) &&
                (this.ApplicationServerPorts == null && other.ApplicationServerPorts == null ||
                 this.ApplicationServerPorts?.Equals(other.ApplicationServerPorts) == true) &&
                (this.QosProfile == null && other.QosProfile == null ||
                 this.QosProfile?.Equals(other.QosProfile) == true) &&
                (this.Sink == null && other.Sink == null ||
                 this.Sink?.Equals(other.Sink) == true) &&
                (this.SinkCredential == null && other.SinkCredential == null ||
                 this.SinkCredential?.Equals(other.SinkCredential) == true) &&
                (this.Duration.Equals(other.Duration));
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"Device = {(this.Device == null ? "null" : this.Device.ToString())}");
            toStringOutput.Add($"ApplicationServer = {(this.ApplicationServer == null ? "null" : this.ApplicationServer.ToString())}");
            toStringOutput.Add($"DevicePorts = {(this.DevicePorts == null ? "null" : this.DevicePorts.ToString())}");
            toStringOutput.Add($"ApplicationServerPorts = {(this.ApplicationServerPorts == null ? "null" : this.ApplicationServerPorts.ToString())}");
            toStringOutput.Add($"QosProfile = {this.QosProfile ?? "null"}");
            toStringOutput.Add($"Sink = {this.Sink ?? "null"}");
            toStringOutput.Add($"SinkCredential = {(this.SinkCredential == null ? "null" : this.SinkCredential.ToString())}");
            toStringOutput.Add($"Duration = {this.Duration}");
        }
    }
}