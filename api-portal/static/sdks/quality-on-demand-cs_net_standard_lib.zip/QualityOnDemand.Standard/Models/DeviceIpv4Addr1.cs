// <copyright file="DeviceIpv4Addr1.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using JsonSubTypes;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using QualityOnDemand.Standard;
using QualityOnDemand.Standard.Utilities;

namespace QualityOnDemand.Standard.Models
{
    /// <summary>
    /// DeviceIpv4Addr1.
    /// </summary>
    public class DeviceIpv4Addr1
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="DeviceIpv4Addr1"/> class.
        /// </summary>
        public DeviceIpv4Addr1()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="DeviceIpv4Addr1"/> class.
        /// </summary>
        /// <param name="publicAddress">publicAddress.</param>
        /// <param name="publicPort">publicPort.</param>
        /// <param name="privateAddress">privateAddress.</param>
        public DeviceIpv4Addr1(
            string publicAddress,
            int publicPort,
            string privateAddress = null)
        {
            this.PublicAddress = publicAddress;
            this.PrivateAddress = privateAddress;
            this.PublicPort = publicPort;
        }

        /// <summary>
        /// A single IPv4 address with no subnet mask
        /// </summary>
        [JsonConverter(typeof(JsonStringConverter), true)]
        [JsonProperty("publicAddress")]
        [JsonRequired]
        public string PublicAddress { get; set; }

        /// <summary>
        /// A single IPv4 address with no subnet mask
        /// </summary>
        [JsonConverter(typeof(JsonStringConverter))]
        [JsonProperty("privateAddress", NullValueHandling = NullValueHandling.Ignore)]
        public string PrivateAddress { get; set; }

        /// <summary>
        /// TCP or UDP port number
        /// </summary>
        [JsonProperty("publicPort")]
        [JsonRequired]
        public int PublicPort { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();
            this.ToString(toStringOutput);
            return $"DeviceIpv4Addr1 : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj is null) return false;
            if (ReferenceEquals(this, obj)) return true;

            return obj is DeviceIpv4Addr1 other &&
                (this.PublicAddress == null && other.PublicAddress == null ||
                 this.PublicAddress?.Equals(other.PublicAddress) == true) &&
                (this.PrivateAddress == null && other.PrivateAddress == null ||
                 this.PrivateAddress?.Equals(other.PrivateAddress) == true) &&
                (this.PublicPort.Equals(other.PublicPort));
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"PublicAddress = {this.PublicAddress ?? "null"}");
            toStringOutput.Add($"PrivateAddress = {this.PrivateAddress ?? "null"}");
            toStringOutput.Add($"PublicPort = {this.PublicPort}");
        }
    }
}