// <copyright file="EventQosStatusEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using APIMatic.Core.Utilities.Converters;
using Newtonsoft.Json;
using QualityOnDemand.Standard;
using QualityOnDemand.Standard.Utilities;

namespace QualityOnDemand.Standard.Models
{
    /// <summary>
    /// EventQosStatusEnum.
    /// </summary>

    [JsonConverter(typeof(StringEnumConverter))]
    public enum EventQosStatusEnum
    {
        /// <summary>
        /// AVAILABLE.
        /// </summary>
        [EnumMember(Value = "AVAILABLE")]
        AVAILABLE,

        /// <summary>
        /// UNAVAILABLE.
        /// </summary>
        [EnumMember(Value = "UNAVAILABLE")]
        UNAVAILABLE
    }
}