// <copyright file="AccessTokenCredential.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using JsonSubTypes;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using QualityOnDemand.Standard;
using QualityOnDemand.Standard.Utilities;

namespace QualityOnDemand.Standard.Models
{
    /// <summary>
    /// AccessTokenCredential.
    /// </summary>
    public class AccessTokenCredential : SinkCredential
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AccessTokenCredential"/> class.
        /// </summary>
        public AccessTokenCredential()
        {
            this.CredentialType = "ACCESSTOKEN";
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="AccessTokenCredential"/> class.
        /// </summary>
        /// <param name="accessToken">accessToken.</param>
        /// <param name="accessTokenExpiresUtc">accessTokenExpiresUtc.</param>
        /// <param name="accessTokenType">accessTokenType.</param>
        /// <param name="credentialType">credentialType.</param>
        public AccessTokenCredential(
            string accessToken,
            DateTime accessTokenExpiresUtc,
            string accessTokenType,
            string credentialType = "ACCESSTOKEN")
            : base(
                credentialType)
        {
            this.AccessToken = accessToken;
            this.AccessTokenExpiresUtc = accessTokenExpiresUtc;
            this.AccessTokenType = accessTokenType;
        }

        /// <summary>
        /// REQUIRED. An access token is a previously acquired token granting access to the target resource.
        /// </summary>
        [JsonProperty("accessToken")]
        public string AccessToken { get; set; }

        /// <summary>
        /// REQUIRED. An absolute (UTC) timestamp at which the token shall be considered expired. Token expiration should occur
        /// after the termination of the requested session, allowing the client to be notified of any changes during the
        /// sessions's existence. If the token expires while the session is still active, the client will stop receiving notifications.
        /// If the access token is a JWT and registered "exp" (Expiration Time) claim is present, the two expiry times should match.
        /// It must follow [RFC 3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6) and must have time zone.
        /// Recommended format is yyyy-MM-dd'T'HH:mm:ss.SSSZ (i.e. which allows 2023-07-03T14:27:08.312+02:00 or 2023-07-03T12:27:08.312Z)
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("accessTokenExpiresUtc")]
        public DateTime AccessTokenExpiresUtc { get; set; }

        /// <summary>
        /// REQUIRED. Type of the access token (See [OAuth 2.0](https://tools.ietf.org/html/rfc6749#section-7.1)). For the current version of the API the type MUST be set to `Bearer`.
        /// </summary>
        [JsonProperty("accessTokenType")]
        public string AccessTokenType { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();
            this.ToString(toStringOutput);
            return $"AccessTokenCredential : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj is null) return false;
            if (ReferenceEquals(this, obj)) return true;

            return obj is AccessTokenCredential other &&
                (this.AccessToken == null && other.AccessToken == null ||
                 this.AccessToken?.Equals(other.AccessToken) == true) &&
                (this.AccessTokenExpiresUtc.Equals(other.AccessTokenExpiresUtc)) &&
                (this.AccessTokenType == null && other.AccessTokenType == null ||
                 this.AccessTokenType?.Equals(other.AccessTokenType) == true) &&
                base.Equals(obj);
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected new void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"AccessToken = {this.AccessToken ?? "null"}");
            toStringOutput.Add($"AccessTokenExpiresUtc = {this.AccessTokenExpiresUtc}");
            toStringOutput.Add($"AccessTokenType = {this.AccessTokenType ?? "null"}");

            base.ToString(toStringOutput);
        }
    }
}