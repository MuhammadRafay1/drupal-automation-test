// <copyright file="EventQosStatusChanged.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using JsonSubTypes;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using QualityOnDemand.Standard;
using QualityOnDemand.Standard.Utilities;

namespace QualityOnDemand.Standard.Models
{
    /// <summary>
    /// EventQosStatusChanged.
    /// </summary>
    public class EventQosStatusChanged : CloudEvent
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="EventQosStatusChanged"/> class.
        /// </summary>
        public EventQosStatusChanged()
        {
            this.Type = "org.camaraproject.quality-on-demand.v1.qos-status-changed";
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="EventQosStatusChanged"/> class.
        /// </summary>
        /// <param name="id">id.</param>
        /// <param name="source">source.</param>
        /// <param name="specversion">specversion.</param>
        /// <param name="time">time.</param>
        /// <param name="type">type.</param>
        /// <param name="datacontenttype">datacontenttype.</param>
        /// <param name="data">data.</param>
        public EventQosStatusChanged(
            string id,
            string source,
            string specversion,
            DateTime time,
            string type = "org.camaraproject.quality-on-demand.v1.qos-status-changed",
            Models.DatacontenttypeEnum? datacontenttype = null,
            object data = null)
            : base(
                id,
                source,
                specversion,
                time,
                type,
                datacontenttype,
                data)
        {
        }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();
            this.ToString(toStringOutput);
            return $"EventQosStatusChanged : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj is null) return false;
            if (ReferenceEquals(this, obj)) return true;

            return obj is EventQosStatusChanged other &&
                base.Equals(obj);
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected new void ToString(List<string> toStringOutput)
        {

            base.ToString(toStringOutput);
        }
    }
}