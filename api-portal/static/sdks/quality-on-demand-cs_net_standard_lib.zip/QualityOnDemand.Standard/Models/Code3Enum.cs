// <copyright file="Code3Enum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using APIMatic.Core.Utilities.Converters;
using Newtonsoft.Json;
using QualityOnDemand.Standard;
using QualityOnDemand.Standard.Utilities;

namespace QualityOnDemand.Standard.Models
{
    /// <summary>
    /// Code3Enum.
    /// </summary>

    [JsonConverter(typeof(StringEnumConverter))]
    public enum Code3Enum
    {
        /// <summary>
        /// QUOTAEXCEEDED.
        /// </summary>
        [EnumMember(Value = "QUOTA_EXCEEDED")]
        QUOTAEXCEEDED,

        /// <summary>
        /// TOOMANYREQUESTS.
        /// </summary>
        [EnumMember(Value = "TOO_MANY_REQUESTS")]
        TOOMANYREQUESTS
    }
}