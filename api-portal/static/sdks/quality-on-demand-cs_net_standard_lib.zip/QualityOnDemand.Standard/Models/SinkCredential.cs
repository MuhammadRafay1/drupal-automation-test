// <copyright file="SinkCredential.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using JsonSubTypes;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using QualityOnDemand.Standard;
using QualityOnDemand.Standard.Utilities;

namespace QualityOnDemand.Standard.Models
{
    /// <summary>
    /// SinkCredential.
    /// </summary>
    [JsonConverter(typeof(JsonSubtypes), "credentialType")]
    [JsonSubtypes.KnownSubType(typeof(PlainCredential), "PLAIN")]
    [JsonSubtypes.KnownSubType(typeof(AccessTokenCredential), "ACCESSTOKEN")]
    [JsonSubtypes.KnownSubType(typeof(RefreshTokenCredential), "REFRESHTOKEN")]
    public class SinkCredential
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="SinkCredential"/> class.
        /// </summary>
        public SinkCredential()
        {
            this.CredentialType = "SinkCredential";
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="SinkCredential"/> class.
        /// </summary>
        /// <param name="credentialType">credentialType.</param>
        public SinkCredential(
            string credentialType = "SinkCredential")
        {
            this.CredentialType = credentialType;
        }

        /// <summary>
        /// Gets or sets CredentialType.
        /// </summary>
        [JsonProperty("credentialType", NullValueHandling = NullValueHandling.Ignore)]
        public string CredentialType { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();
            this.ToString(toStringOutput);
            return $"SinkCredential : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj is null) return false;
            if (ReferenceEquals(this, obj)) return true;

            return obj is SinkCredential other &&
                (this.CredentialType == null && other.CredentialType == null ||
                 this.CredentialType?.Equals(other.CredentialType) == true);
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"CredentialType = {this.CredentialType ?? "null"}");
        }
    }
}