// <copyright file="DeviceIpv4Addr2.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using JsonSubTypes;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using QualityOnDemand.Standard;
using QualityOnDemand.Standard.Utilities;

namespace QualityOnDemand.Standard.Models
{
    /// <summary>
    /// DeviceIpv4Addr2.
    /// </summary>
    public class DeviceIpv4Addr2
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="DeviceIpv4Addr2"/> class.
        /// </summary>
        public DeviceIpv4Addr2()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="DeviceIpv4Addr2"/> class.
        /// </summary>
        /// <param name="publicAddress">publicAddress.</param>
        /// <param name="privateAddress">privateAddress.</param>
        /// <param name="publicPort">publicPort.</param>
        public DeviceIpv4Addr2(
            string publicAddress = null,
            string privateAddress = null,
            int? publicPort = null)
        {
            this.PublicAddress = publicAddress;
            this.PrivateAddress = privateAddress;
            this.PublicPort = publicPort;
        }

        /// <summary>
        /// A single IPv4 address with no subnet mask
        /// </summary>
        [JsonProperty("publicAddress", NullValueHandling = NullValueHandling.Ignore)]
        public string PublicAddress { get; set; }

        /// <summary>
        /// A single IPv4 address with no subnet mask
        /// </summary>
        [JsonProperty("privateAddress", NullValueHandling = NullValueHandling.Ignore)]
        public string PrivateAddress { get; set; }

        /// <summary>
        /// TCP or UDP port number
        /// </summary>
        [JsonProperty("publicPort", NullValueHandling = NullValueHandling.Ignore)]
        public int? PublicPort { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();
            this.ToString(toStringOutput);
            return $"DeviceIpv4Addr2 : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj is null) return false;
            if (ReferenceEquals(this, obj)) return true;

            return obj is DeviceIpv4Addr2 other &&
                (this.PublicAddress == null && other.PublicAddress == null ||
                 this.PublicAddress?.Equals(other.PublicAddress) == true) &&
                (this.PrivateAddress == null && other.PrivateAddress == null ||
                 this.PrivateAddress?.Equals(other.PrivateAddress) == true) &&
                (this.PublicPort == null && other.PublicPort == null ||
                 this.PublicPort?.Equals(other.PublicPort) == true);
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"PublicAddress = {this.PublicAddress ?? "null"}");
            toStringOutput.Add($"PrivateAddress = {this.PrivateAddress ?? "null"}");
            toStringOutput.Add($"PublicPort = {(this.PublicPort == null ? "null" : this.PublicPort.ToString())}");
        }
    }
}