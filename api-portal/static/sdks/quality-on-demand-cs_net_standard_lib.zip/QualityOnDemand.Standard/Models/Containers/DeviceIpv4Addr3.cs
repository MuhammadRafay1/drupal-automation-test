// <copyright file="DeviceIpv4Addr3.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using APIMatic.Core.Utilities.Converters;
using Newtonsoft.Json;
using System;

namespace QualityOnDemand.Standard.Models.Containers
{
    /// <summary>
    /// This is a container class for any-of types.
    /// </summary>
    [JsonConverter(
        typeof(UnionTypeConverter<DeviceIpv4Addr3>),
        new Type[] {
            typeof(DeviceIpv4AddrCase),
            typeof(DeviceIpv4Addr1Case)
        },
        false
    )]
    public abstract class DeviceIpv4Addr3
    {
        /// <summary>
        /// This is DeviceIpv4Addr case.
        /// </summary>
        /// <returns>
        /// The DeviceIpv4Addr3 instance, wrapping the provided DeviceIpv4Addr value.
        /// </returns>
        public static DeviceIpv4Addr3 FromDeviceIpv4Addr(DeviceIpv4Addr deviceIpv4Addr)
        {
            return new DeviceIpv4AddrCase().Set(deviceIpv4Addr);
        }

        /// <summary>
        /// This is DeviceIpv4Addr1 case.
        /// </summary>
        /// <returns>
        /// The DeviceIpv4Addr3 instance, wrapping the provided DeviceIpv4Addr1 value.
        /// </returns>
        public static DeviceIpv4Addr3 FromDeviceIpv4Addr1(DeviceIpv4Addr1 deviceIpv4Addr1)
        {
            return new DeviceIpv4Addr1Case().Set(deviceIpv4Addr1);
        }

        /// <summary>
        /// Method to match from the provided any-of cases. Here parameters
        /// represents the callback functions for any-of type cases. All
        /// callback functions must have the same return type T. This typeparam T
        /// represents the type that will be returned after applying the selected
        /// callback function.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        public abstract T Match<T>(Func<DeviceIpv4Addr, T> deviceIpv4Addr, Func<DeviceIpv4Addr1, T> deviceIpv4Addr1);

        [JsonConverter(typeof(UnionTypeCaseConverter<DeviceIpv4AddrCase, DeviceIpv4Addr>))]
        private sealed class DeviceIpv4AddrCase : DeviceIpv4Addr3, ICaseValue<DeviceIpv4AddrCase, DeviceIpv4Addr>
        {
            public DeviceIpv4Addr _value;

            public override T Match<T>(Func<DeviceIpv4Addr, T> deviceIpv4Addr, Func<DeviceIpv4Addr1, T> deviceIpv4Addr1)
            {
                return deviceIpv4Addr(_value);
            }

            public DeviceIpv4AddrCase Set(DeviceIpv4Addr value)
            {
                _value = value;
                return this;
            }

            public DeviceIpv4Addr Get()
            {
                return _value;
            }

            public override string ToString()
            {
                return _value?.ToString();
            }

            public override bool Equals(object obj)
            {
                if (!(obj is DeviceIpv4AddrCase other)) return false;
                if (ReferenceEquals(this, other)) return true;
                return _value == null ? other._value == null : _value?.Equals(other._value) == true;
            }
        }

        [JsonConverter(typeof(UnionTypeCaseConverter<DeviceIpv4Addr1Case, DeviceIpv4Addr1>))]
        private sealed class DeviceIpv4Addr1Case : DeviceIpv4Addr3, ICaseValue<DeviceIpv4Addr1Case, DeviceIpv4Addr1>
        {
            public DeviceIpv4Addr1 _value;

            public override T Match<T>(Func<DeviceIpv4Addr, T> deviceIpv4Addr, Func<DeviceIpv4Addr1, T> deviceIpv4Addr1)
            {
                return deviceIpv4Addr1(_value);
            }

            public DeviceIpv4Addr1Case Set(DeviceIpv4Addr1 value)
            {
                _value = value;
                return this;
            }

            public DeviceIpv4Addr1 Get()
            {
                return _value;
            }

            public override string ToString()
            {
                return _value?.ToString();
            }

            public override bool Equals(object obj)
            {
                if (!(obj is DeviceIpv4Addr1Case other)) return false;
                if (ReferenceEquals(this, other)) return true;
                return _value == null ? other._value == null : _value?.Equals(other._value) == true;
            }
        }
    }
}