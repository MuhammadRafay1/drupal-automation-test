// <copyright file="Code1Enum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using APIMatic.Core.Utilities.Converters;
using Newtonsoft.Json;
using QualityOnDemand.Standard;
using QualityOnDemand.Standard.Utilities;

namespace QualityOnDemand.Standard.Models
{
    /// <summary>
    /// Code1Enum.
    /// </summary>

    [JsonConverter(typeof(StringEnumConverter))]
    public enum Code1Enum
    {
        /// <summary>
        /// NOTFOUND.
        /// </summary>
        [EnumMember(Value = "NOT_FOUND")]
        NOTFOUND,

        /// <summary>
        /// IDENTIFIERNOTFOUND.
        /// </summary>
        [EnumMember(Value = "IDENTIFIER_NOT_FOUND")]
        IDENTIFIERNOTFOUND
    }
}