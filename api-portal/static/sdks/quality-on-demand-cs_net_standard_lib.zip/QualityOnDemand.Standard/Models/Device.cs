// <copyright file="Device.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using JsonSubTypes;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using QualityOnDemand.Standard;
using QualityOnDemand.Standard.Models.Containers;
using QualityOnDemand.Standard.Utilities;

namespace QualityOnDemand.Standard.Models
{
    /// <summary>
    /// Device.
    /// </summary>
    public class Device
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Device"/> class.
        /// </summary>
        public Device()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Device"/> class.
        /// </summary>
        /// <param name="phoneNumber">phoneNumber.</param>
        /// <param name="networkAccessIdentifier">networkAccessIdentifier.</param>
        /// <param name="ipv4Address">ipv4Address.</param>
        /// <param name="ipv6Address">ipv6Address.</param>
        public Device(
            string phoneNumber = null,
            string networkAccessIdentifier = null,
            DeviceIpv4Addr3 ipv4Address = null,
            string ipv6Address = null)
        {
            this.PhoneNumber = phoneNumber;
            this.NetworkAccessIdentifier = networkAccessIdentifier;
            this.Ipv4Address = ipv4Address;
            this.Ipv6Address = ipv6Address;
        }

        /// <summary>
        /// A public identifier addressing a telephone subscription. In mobile networks it corresponds to the MSISDN (Mobile Station International Subscriber Directory Number). In order to be globally unique it has to be formatted in international format, according to E.164 standard, prefixed with '+'.
        /// </summary>
        [JsonProperty("phoneNumber", NullValueHandling = NullValueHandling.Ignore)]
        public string PhoneNumber { get; set; }

        /// <summary>
        /// A public identifier addressing a subscription in a mobile network. In 3GPP terminology, it corresponds to the GPSI formatted with the External Identifier ({Local Identifier}@{Domain Identifier}). Unlike the telephone number, the network access identifier is not subjected to portability ruling in force, and is individually managed by each operator.
        /// </summary>
        [JsonProperty("networkAccessIdentifier", NullValueHandling = NullValueHandling.Ignore)]
        public string NetworkAccessIdentifier { get; set; }

        /// <summary>
        /// The device should be identified by either the public (observed) IP address and port as seen by the application server, or the private (local) and any public (observed) IP addresses in use by the device (this information can be obtained by various means, for example from some DNS servers).
        /// If the allocated and observed IP addresses are the same (i.e. NAT is not in use) then  the same address should be specified for both publicAddress and privateAddress.
        /// If NAT64 is in use, the device should be identified by its publicAddress and publicPort, or separately by its allocated IPv6 address (field ipv6Address of the Device object)
        /// In all cases, publicAddress must be specified, along with at least one of either privateAddress or publicPort, dependent upon which is known. In general, mobile devices cannot be identified by their public IPv4 address alone.
        /// </summary>
        [JsonProperty("ipv4Address", NullValueHandling = NullValueHandling.Ignore)]
        public DeviceIpv4Addr3 Ipv4Address { get; set; }

        /// <summary>
        /// The device should be identified by the observed IPv6 address, or by any single IPv6 address from within the subnet allocated to the device (e.g. adding ::0 to the /64 prefix).
        /// The session shall apply to all IP flows between the device subnet and the specified application server, unless further restricted by the optional parameters devicePorts or applicationServerPorts.
        /// </summary>
        [JsonProperty("ipv6Address", NullValueHandling = NullValueHandling.Ignore)]
        public string Ipv6Address { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();
            this.ToString(toStringOutput);
            return $"Device : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj is null) return false;
            if (ReferenceEquals(this, obj)) return true;

            return obj is Device other &&
                (this.PhoneNumber == null && other.PhoneNumber == null ||
                 this.PhoneNumber?.Equals(other.PhoneNumber) == true) &&
                (this.NetworkAccessIdentifier == null && other.NetworkAccessIdentifier == null ||
                 this.NetworkAccessIdentifier?.Equals(other.NetworkAccessIdentifier) == true) &&
                (this.Ipv4Address == null && other.Ipv4Address == null ||
                 this.Ipv4Address?.Equals(other.Ipv4Address) == true) &&
                (this.Ipv6Address == null && other.Ipv6Address == null ||
                 this.Ipv6Address?.Equals(other.Ipv6Address) == true);
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"PhoneNumber = {this.PhoneNumber ?? "null"}");
            toStringOutput.Add($"NetworkAccessIdentifier = {this.NetworkAccessIdentifier ?? "null"}");
            toStringOutput.Add($"Ipv4Address = {(this.Ipv4Address == null ? "null" : this.Ipv4Address.ToString())}");
            toStringOutput.Add($"Ipv6Address = {this.Ipv6Address ?? "null"}");
        }
    }
}