// <copyright file="StatusInfoEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using APIMatic.Core.Utilities.Converters;
using Newtonsoft.Json;
using QualityOnDemand.Standard;
using QualityOnDemand.Standard.Utilities;

namespace QualityOnDemand.Standard.Models
{
    /// <summary>
    /// StatusInfoEnum.
    /// </summary>

    [JsonConverter(typeof(StringEnumConverter))]
    public enum StatusInfoEnum
    {
        /// <summary>
        /// DURATIONEXPIRED.
        /// </summary>
        [EnumMember(Value = "DURATION_EXPIRED")]
        DURATIONEXPIRED,

        /// <summary>
        /// NETWORKTERMINATED.
        /// </summary>
        [EnumMember(Value = "NETWORK_TERMINATED")]
        NETWORKTERMINATED,

        /// <summary>
        /// DELETEREQUESTED.
        /// </summary>
        [EnumMember(Value = "DELETE_REQUESTED")]
        DELETEREQUESTED
    }
}