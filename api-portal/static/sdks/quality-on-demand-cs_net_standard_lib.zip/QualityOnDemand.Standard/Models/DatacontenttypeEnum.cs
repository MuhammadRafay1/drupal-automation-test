// <copyright file="DatacontenttypeEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using APIMatic.Core.Utilities.Converters;
using Newtonsoft.Json;
using QualityOnDemand.Standard;
using QualityOnDemand.Standard.Utilities;

namespace QualityOnDemand.Standard.Models
{
    /// <summary>
    /// DatacontenttypeEnum.
    /// </summary>

    [JsonConverter(typeof(StringEnumConverter))]
    public enum DatacontenttypeEnum
    {
        /// <summary>
        /// EnumApplicationjson.
        /// </summary>
        [EnumMember(Value = "application/json")]
        EnumApplicationjson
    }
}