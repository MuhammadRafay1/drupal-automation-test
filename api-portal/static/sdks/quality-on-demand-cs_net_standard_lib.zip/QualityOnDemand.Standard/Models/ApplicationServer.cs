// <copyright file="ApplicationServer.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using JsonSubTypes;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using QualityOnDemand.Standard;
using QualityOnDemand.Standard.Utilities;

namespace QualityOnDemand.Standard.Models
{
    /// <summary>
    /// ApplicationServer.
    /// </summary>
    public class ApplicationServer
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ApplicationServer"/> class.
        /// </summary>
        public ApplicationServer()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ApplicationServer"/> class.
        /// </summary>
        /// <param name="ipv4Address">ipv4Address.</param>
        /// <param name="ipv6Address">ipv6Address.</param>
        public ApplicationServer(
            string ipv4Address = null,
            string ipv6Address = null)
        {
            this.Ipv4Address = ipv4Address;
            this.Ipv6Address = ipv6Address;
        }

        /// <summary>
        /// <![CDATA[
        /// IPv4 address may be specified in form <address/mask> as:
        ///   - address - an IPv4 number in dotted-quad form 1.2.3.4. Only this exact IP number will match the flow control rule.
        ///   - address/mask - an IP number as above with a mask width of the form 1.2.3.4/24.
        ///     In this case, all IP numbers from 1.2.3.0 to 1.2.3.255 will match. The bit width MUST be valid for the IP version.
        /// ]]>
        /// </summary>
        [JsonProperty("ipv4Address", NullValueHandling = NullValueHandling.Ignore)]
        public string Ipv4Address { get; set; }

        /// <summary>
        /// <![CDATA[
        /// IPv6 address may be specified in form <address/mask> as:
        ///   - address - The /128 subnet is optional for single addresses:
        ///     - 2001:db8:85a3:8d3:1319:8a2e:370:7344
        ///     - 2001:db8:85a3:8d3:1319:8a2e:370:7344/128
        ///   - address/mask - an IP v6 number with a mask:
        ///     - 2001:db8:85a3:8d3::0/64
        ///     - 2001:db8:85a3:8d3::/64
        /// ]]>
        /// </summary>
        [JsonProperty("ipv6Address", NullValueHandling = NullValueHandling.Ignore)]
        public string Ipv6Address { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();
            this.ToString(toStringOutput);
            return $"ApplicationServer : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj is null) return false;
            if (ReferenceEquals(this, obj)) return true;

            return obj is ApplicationServer other &&
                (this.Ipv4Address == null && other.Ipv4Address == null ||
                 this.Ipv4Address?.Equals(other.Ipv4Address) == true) &&
                (this.Ipv6Address == null && other.Ipv6Address == null ||
                 this.Ipv6Address?.Equals(other.Ipv6Address) == true);
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"Ipv4Address = {this.Ipv4Address ?? "null"}");
            toStringOutput.Add($"Ipv6Address = {this.Ipv6Address ?? "null"}");
        }
    }
}