// <copyright file="Code2Enum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using APIMatic.Core.Utilities.Converters;
using Newtonsoft.Json;
using QualityOnDemand.Standard;
using QualityOnDemand.Standard.Utilities;

namespace QualityOnDemand.Standard.Models
{
    /// <summary>
    /// Code2Enum.
    /// </summary>

    [JsonConverter(typeof(StringEnumConverter))]
    public enum Code2Enum
    {
        /// <summary>
        /// IDENTIFIERMISMATCH.
        /// </summary>
        [EnumMember(Value = "IDENTIFIER_MISMATCH")]
        IDENTIFIERMISMATCH,

        /// <summary>
        /// SERVICENOTAPPLICABLE.
        /// </summary>
        [EnumMember(Value = "SERVICE_NOT_APPLICABLE")]
        SERVICENOTAPPLICABLE,

        /// <summary>
        /// MISSINGIDENTIFIER.
        /// </summary>
        [EnumMember(Value = "MISSING_IDENTIFIER")]
        MISSINGIDENTIFIER,

        /// <summary>
        /// UNSUPPORTEDIDENTIFIER.
        /// </summary>
        [EnumMember(Value = "UNSUPPORTED_IDENTIFIER")]
        UNSUPPORTEDIDENTIFIER,

        /// <summary>
        /// UNNECESSARYIDENTIFIER.
        /// </summary>
        [EnumMember(Value = "UNNECESSARY_IDENTIFIER")]
        UNNECESSARYIDENTIFIER,

        /// <summary>
        /// EnumQUALITYONDEMANDQOSPROFILENOTAPPLICABLE.
        /// </summary>
        [EnumMember(Value = "QUALITY_ON_DEMAND.QOS_PROFILE_NOT_APPLICABLE")]
        EnumQUALITYONDEMANDQOSPROFILENOTAPPLICABLE
    }
}