// <copyright file="PortsSpec.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using JsonSubTypes;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using QualityOnDemand.Standard;
using QualityOnDemand.Standard.Utilities;

namespace QualityOnDemand.Standard.Models
{
    /// <summary>
    /// PortsSpec.
    /// </summary>
    public class PortsSpec
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PortsSpec"/> class.
        /// </summary>
        public PortsSpec()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PortsSpec"/> class.
        /// </summary>
        /// <param name="ranges">ranges.</param>
        /// <param name="ports">ports.</param>
        public PortsSpec(
            List<Models.Range> ranges = null,
            List<int> ports = null)
        {
            this.Ranges = ranges;
            this.Ports = ports;
        }

        /// <summary>
        /// Range of TCP or UDP ports
        /// </summary>
        [JsonProperty("ranges", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.Range> Ranges { get; set; }

        /// <summary>
        /// Array of TCP or UDP ports
        /// </summary>
        [JsonProperty("ports", NullValueHandling = NullValueHandling.Ignore)]
        public List<int> Ports { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();
            this.ToString(toStringOutput);
            return $"PortsSpec : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj is null) return false;
            if (ReferenceEquals(this, obj)) return true;

            return obj is PortsSpec other &&
                (this.Ranges == null && other.Ranges == null ||
                 this.Ranges?.Equals(other.Ranges) == true) &&
                (this.Ports == null && other.Ports == null ||
                 this.Ports?.Equals(other.Ports) == true);
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"Ranges = {(this.Ranges == null ? "null" : $"[{string.Join(", ", this.Ranges)} ]")}");
            toStringOutput.Add($"Ports = {(this.Ports == null ? "null" : $"[{string.Join(", ", this.Ports)} ]")}");
        }
    }
}