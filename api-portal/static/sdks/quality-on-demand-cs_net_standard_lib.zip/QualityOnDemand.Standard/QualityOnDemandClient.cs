// <copyright file="QualityOnDemandClient.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.Linq;
using APIMatic.Core;
using APIMatic.Core.Authentication;
using QualityOnDemand.Standard.Authentication;
using QualityOnDemand.Standard.Controllers;
using QualityOnDemand.Standard.Http.Client;
using QualityOnDemand.Standard.Utilities;

namespace QualityOnDemand.Standard
{
    /// <summary>
    /// The gateway for the SDK. This class acts as a factory for Controller and
    /// holds the configuration of the SDK.
    /// </summary>
    public sealed class QualityOnDemandClient : IConfiguration
    {
        // A map of environments and their corresponding servers/baseurls
        private static readonly Dictionary<Environment, Dictionary<Enum, string>> EnvironmentsMap =
            new Dictionary<Environment, Dictionary<Enum, string>>
        {
            {
                Environment.Production, new Dictionary<Enum, string>
                {
                    { Server.Default, "{apiRoot}/quality-on-demand/vwip" },
                    { Server.AuthServer, "https://example.com/.well-known" },
                }
            },
        };

        private readonly GlobalConfiguration globalConfiguration;
        private const string userAgent = "APIMATIC 3.0";
        private readonly HttpCallback httpCallback;
        private readonly Lazy<QoSSessionsController> qoSSessions;

        private QualityOnDemandClient(
            Environment environment,
            string apiRoot,
            OpenIdModel openIdModel,
            NotificationsBearerAuthModel notificationsBearerAuthModel,
            HttpCallback httpCallback,
            IHttpClientConfiguration httpClientConfiguration)
        {
            this.Environment = environment;
            this.ApiRoot = apiRoot;
            this.httpCallback = httpCallback;
            this.HttpClientConfiguration = httpClientConfiguration;
            OpenIdModel = openIdModel;
            var openIdManager = new OpenIdManager(openIdModel);
            NotificationsBearerAuthModel = notificationsBearerAuthModel;
            var notificationsBearerAuthManager = new NotificationsBearerAuthManager(notificationsBearerAuthModel);
            globalConfiguration = new GlobalConfiguration.Builder()
                .AuthManagers(new Dictionary<string, AuthManager> {
                    {"openId", openIdManager},
                    {"notificationsBearerAuth", notificationsBearerAuthManager},
                })
                .ApiCallback(httpCallback)
                .HttpConfiguration(httpClientConfiguration)
                .ServerUrls(EnvironmentsMap[environment], Server.Default)
                .Parameters(globalParameter => globalParameter
                    .Template(templateParameter => templateParameter.Setup("apiRoot", this.ApiRoot)))
                .UserAgent(userAgent)
                .Build();

            OpenIdCredentials = openIdManager;
            NotificationsBearerAuthCredentials = notificationsBearerAuthManager;

            this.qoSSessions = new Lazy<QoSSessionsController>(
                () => new QoSSessionsController(globalConfiguration));
        }

        /// <summary>
        /// Gets QoSSessionsController controller.
        /// </summary>
        public QoSSessionsController QoSSessionsController => this.qoSSessions.Value;

        /// <summary>
        /// Gets the configuration of the Http Client associated with this client.
        /// </summary>
        public IHttpClientConfiguration HttpClientConfiguration { get; }

        /// <summary>
        /// Gets Environment.
        /// Current API environment.
        /// </summary>
        public Environment Environment { get; }

        /// <summary>
        /// Gets ApiRoot.
        /// API root, defined by the service provider, e.g. `api.example.com` or `api.example.com/somepath`.
        /// </summary>
        public string ApiRoot { get; }

        /// <summary>
        /// Gets http callback.
        /// </summary>
        public HttpCallback HttpCallback => this.httpCallback;

        /// <summary>
        /// Gets the credentials to use with OpenId.
        /// </summary>
        public IOpenIdCredentials OpenIdCredentials { get; private set; }

        /// <summary>
        /// Gets the credentials model to use with OpenId.
        /// </summary>
        public OpenIdModel OpenIdModel { get; private set; }

        /// <summary>
        /// Gets the access token to use with OAuth 2 authentication.
        /// </summary>
        public string AccessToken => this.OpenIdCredentials.AccessToken;

        /// <summary>
        /// Gets the credentials to use with NotificationsBearerAuth.
        /// </summary>
        public INotificationsBearerAuthCredentials NotificationsBearerAuthCredentials { get; private set; }

        /// <summary>
        /// Gets the credentials model to use with NotificationsBearerAuth.
        /// </summary>
        public NotificationsBearerAuthModel NotificationsBearerAuthModel { get; private set; }

        /// <summary>
        /// Gets the access token to use with OAuth 2 authentication.
        /// </summary>
        public string AccessToken2 => this.NotificationsBearerAuthCredentials.AccessToken;

        /// <summary>
        /// Gets the URL for a particular alias in the current environment and appends
        /// it with template parameters.
        /// </summary>
        /// <param name="alias">Default value:DEFAULT.</param>
        /// <returns>Returns the baseurl.</returns>
        public string GetBaseUri(Server alias = Server.Default)
        {
            return globalConfiguration.ServerUrl(alias);
        }

        /// <summary>
        /// Creates an object of the QualityOnDemandClient using the values provided for the builder.
        /// </summary>
        /// <returns>Builder.</returns>
        public Builder ToBuilder()
        {
            Builder builder = new Builder()
                .Environment(this.Environment)
                .ApiRoot(this.ApiRoot)
                .HttpCallback(httpCallback)
                .HttpClientConfig(config => config.Build());

            if (OpenIdModel != null)
            {
                builder.OpenIdCredentials(OpenIdModel.ToBuilder().Build());
            }

            if (NotificationsBearerAuthModel != null)
            {
                builder.NotificationsBearerAuthCredentials(NotificationsBearerAuthModel.ToBuilder().Build());
            }

            return builder;
        }

        /// <inheritdoc/>
        public override string ToString()
        {
            return
                $"Environment = {this.Environment}, " +
                $"ApiRoot = {this.ApiRoot}, " +
                $"HttpClientConfiguration = {this.HttpClientConfiguration}, ";
        }

        /// <summary>
        /// Creates the client using builder.
        /// </summary>
        /// <returns> QualityOnDemandClient.</returns>
        internal static QualityOnDemandClient CreateFromEnvironment()
        {
            var builder = new Builder();

            string environment = System.Environment.GetEnvironmentVariable("QUALITY_ON_DEMAND_STANDARD_ENVIRONMENT");
            string apiRoot = System.Environment.GetEnvironmentVariable("QUALITY_ON_DEMAND_STANDARD_API_ROOT");
            string accessToken = System.Environment.GetEnvironmentVariable("QUALITY_ON_DEMAND_STANDARD_ACCESS_TOKEN");
            string accessToken2 = System.Environment.GetEnvironmentVariable("QUALITY_ON_DEMAND_STANDARD_ACCESS_TOKEN_2");

            if (environment != null)
            {
                builder.Environment(ApiHelper.JsonDeserialize<Environment>($"\"{environment}\""));
            }

            if (apiRoot != null)
            {
                builder.ApiRoot(apiRoot);
            }

            if (accessToken != null)
            {
                builder.OpenIdCredentials(new OpenIdModel
                .Builder(accessToken)
                .Build());
            }

            if (accessToken2 != null)
            {
                builder.NotificationsBearerAuthCredentials(new NotificationsBearerAuthModel
                .Builder(accessToken2)
                .Build());
            }

            return builder.Build();
        }

        /// <summary>
        /// Builder class.
        /// </summary>
        public class Builder
        {
            private Environment environment = QualityOnDemand.Standard.Environment.Production;
            private string apiRoot = "http://localhost:9091";
            private OpenIdModel openIdModel = new OpenIdModel();
            private NotificationsBearerAuthModel notificationsBearerAuthModel = new NotificationsBearerAuthModel();
            private HttpClientConfiguration.Builder httpClientConfig = new HttpClientConfiguration.Builder();
            private HttpCallback httpCallback;

            /// <summary>
            /// Sets credentials for OpenId.
            /// </summary>
            /// <param name="openIdModel">OpenIdModel.</param>
            /// <returns>Builder.</returns>
            public Builder OpenIdCredentials(OpenIdModel openIdModel)
            {
                if (openIdModel is null)
                {
                    throw new ArgumentNullException(nameof(openIdModel));
                }

                this.openIdModel = openIdModel;
                return this;
            }

            /// <summary>
            /// Sets credentials for NotificationsBearerAuth.
            /// </summary>
            /// <param name="notificationsBearerAuthModel">NotificationsBearerAuthModel.</param>
            /// <returns>Builder.</returns>
            public Builder NotificationsBearerAuthCredentials(NotificationsBearerAuthModel notificationsBearerAuthModel)
            {
                if (notificationsBearerAuthModel is null)
                {
                    throw new ArgumentNullException(nameof(notificationsBearerAuthModel));
                }

                this.notificationsBearerAuthModel = notificationsBearerAuthModel;
                return this;
            }

            /// <summary>
            /// Sets Environment.
            /// </summary>
            /// <param name="environment"> Environment. </param>
            /// <returns> Builder. </returns>
            public Builder Environment(Environment environment)
            {
                this.environment = environment;
                return this;
            }

            /// <summary>
            /// Sets ApiRoot.
            /// </summary>
            /// <param name="apiRoot"> ApiRoot. </param>
            /// <returns> Builder. </returns>
            public Builder ApiRoot(string apiRoot)
            {
                this.apiRoot = apiRoot ?? throw new ArgumentNullException(nameof(apiRoot));
                return this;
            }

            /// <summary>
            /// Sets HttpClientConfig.
            /// </summary>
            /// <param name="action"> Action. </param>
            /// <returns>Builder.</returns>
            public Builder HttpClientConfig(Action<HttpClientConfiguration.Builder> action)
            {
                if (action is null)
                {
                    throw new ArgumentNullException(nameof(action));
                }

                action(this.httpClientConfig);
                return this;
            }



            /// <summary>
            /// Sets the HttpCallback for the Builder.
            /// </summary>
            /// <param name="httpCallback"> http callback. </param>
            /// <returns>Builder.</returns>
            public Builder HttpCallback(HttpCallback httpCallback)
            {
                this.httpCallback = httpCallback;
                return this;
            }

            /// <summary>
            /// Creates an object of the QualityOnDemandClient using the values provided for the builder.
            /// </summary>
            /// <returns>QualityOnDemandClient.</returns>
            public QualityOnDemandClient Build()
            {
                if (openIdModel.AccessToken == null)
                {
                    openIdModel = null;
                }
                if (notificationsBearerAuthModel.AccessToken == null)
                {
                    notificationsBearerAuthModel = null;
                }
                return new QualityOnDemandClient(
                    environment,
                    apiRoot,
                    openIdModel,
                    notificationsBearerAuthModel,
                    httpCallback,
                    httpClientConfig.Build());
            }
        }
    }
}
