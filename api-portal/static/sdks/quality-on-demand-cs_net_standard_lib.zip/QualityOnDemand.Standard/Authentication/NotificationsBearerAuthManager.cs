// <copyright file="NotificationsBearerAuthManager.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using QualityOnDemand.Standard.Http.Request;
using APIMatic.Core.Authentication;

namespace QualityOnDemand.Standard.Authentication
{
    /// <summary>
    /// NotificationsBearerAuthManager.
    /// </summary>
    internal class NotificationsBearerAuthManager : AuthManager, INotificationsBearerAuthCredentials
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="NotificationsBearerAuthManager"/> class.
        /// </summary>
        /// <param name="notificationsBearerAuthModel">NotificationsBearerAuthModel.</param>
        public NotificationsBearerAuthManager(NotificationsBearerAuthModel notificationsBearerAuthModel)
        {
            this.AccessToken = notificationsBearerAuthModel?.AccessToken;
            Parameters(paramBuilder => paramBuilder
                .Header(header => header.Setup("Authorization",
                    this.AccessToken == null ? null : $"Bearer {this.AccessToken}"
                ).Required()));
        }

        /// <summary>
        /// Gets string value for accessToken.
        /// </summary>
        public string AccessToken { get; }

        /// <summary>
        /// Check if credentials match.
        /// </summary>
        /// <param name="accessToken"> The string value for credentials.</param>
        /// <returns> True if credentials matched.</returns>
        public bool Equals(string accessToken)
        {
            return accessToken.Equals(this.AccessToken);
        }

    }

    public sealed class NotificationsBearerAuthModel
    {
        internal NotificationsBearerAuthModel()
        {
        }

        internal string AccessToken { get; set; }

        /// <summary>
        /// Creates an object of the NotificationsBearerAuthModel using the values provided for the builder.
        /// </summary>
        /// <returns>Builder.</returns>
        public Builder ToBuilder()
        {
            return new Builder(AccessToken);
        }

        /// <summary>
        /// Builder class for NotificationsBearerAuthModel.
        /// </summary>
        public class Builder
        {
            private string accessToken;

            public Builder(string accessToken)
            {
                this.accessToken = accessToken ?? throw new ArgumentNullException(nameof(accessToken));
            }

            /// <summary>
            /// Sets AccessToken.
            /// </summary>
            /// <param name="accessToken">AccessToken.</param>
            /// <returns>Builder.</returns>
            public Builder AccessToken(string accessToken)
            {
                this.accessToken = accessToken ?? throw new ArgumentNullException(nameof(accessToken));
                return this;
            }

            /// <summary>
            /// Creates an object of the NotificationsBearerAuthModel using the values provided for the builder.
            /// </summary>
            /// <returns>NotificationsBearerAuthModel.</returns>
            public NotificationsBearerAuthModel Build()
            {
                return new NotificationsBearerAuthModel()
                {
                    AccessToken = this.accessToken
                };
            }
        }
    }
}