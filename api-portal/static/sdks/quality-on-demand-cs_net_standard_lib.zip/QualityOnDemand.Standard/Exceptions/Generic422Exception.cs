// <copyright file="Generic422Exception.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using JsonSubTypes;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using QualityOnDemand.Standard;
using QualityOnDemand.Standard.Http.Client;
using QualityOnDemand.Standard.Models;
using QualityOnDemand.Standard.Utilities;

namespace QualityOnDemand.Standard.Exceptions
{
    /// <summary>
    /// Generic422Exception.
    /// </summary>
    public class Generic422Exception : ApiException
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Generic422Exception"/> class.
        /// </summary>
        /// <param name="reason"> The reason for throwing exception.</param>
        /// <param name="context"> The HTTP context that encapsulates request and response objects.</param>
        public Generic422Exception(string reason, HttpContext context)
            : base(reason, context)
        {
        }

        /// <summary>
        /// HTTP status code returned along with this error response
        /// </summary>
        [JsonProperty("status")]
        public int Status { get; set; }

        /// <summary>
        /// Code given to this error
        /// </summary>
        [JsonProperty("code")]
        public Models.Code6Enum Code { get; set; }

        /// <summary>
        /// Detailed error description
        /// </summary>
        [JsonProperty("message")]
        public new string Message { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();
            this.ToString(toStringOutput);
            return $"Generic422Exception : ({string.Join(", ", toStringOutput)})";
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            base.ToString(toStringOutput);
            toStringOutput.Add($"Status = {this.Status}");
            toStringOutput.Add($"Code = {this.Code}");
            toStringOutput.Add($"Message = {this.Message ?? "null"}");
        }
    }
}