
# Device Ipv 4 Addr

## Structure

`DeviceIpv4Addr`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `publicAddress` | `string` | Required | A single IPv4 address with no subnet mask | getPublicAddress(): string | setPublicAddress(string publicAddress): void |
| `privateAddress` | `string` | Required | A single IPv4 address with no subnet mask | getPrivateAddress(): string | setPrivateAddress(string privateAddress): void |
| `publicPort` | `?int` | Optional | TCP or UDP port number<br><br>**Constraints**: `>= 0`, `<= 65535` | getPublicPort(): ?int | setPublicPort(?int publicPort): void |

## Example (as JSON)

```json
{
  "publicAddress": "203.0.113.0",
  "privateAddress": "203.0.113.0",
  "publicPort": 242
}
```

