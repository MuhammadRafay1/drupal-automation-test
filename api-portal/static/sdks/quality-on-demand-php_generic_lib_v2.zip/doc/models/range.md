
# Range

## Structure

`Range`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `from` | `int` | Required | TCP or UDP port number<br><br>**Constraints**: `>= 0`, `<= 65535` | getFrom(): int | setFrom(int from): void |
| `to` | `int` | Required | TCP or UDP port number<br><br>**Constraints**: `>= 0`, `<= 65535` | getTo(): int | setTo(int to): void |

## Example (as JSON)

```json
{
  "from": 92,
  "to": 12
}
```

