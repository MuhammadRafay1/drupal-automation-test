
# Device Ipv 4 Addr 3

## Data Type

`DeviceIpv4Addr|DeviceIpv4Addr1`

## Cases

| Type |
|  --- |
| [`DeviceIpv4Addr`](../../../doc/models/device-ipv-4-addr.md) |
| [`DeviceIpv4Addr1`](../../../doc/models/device-ipv-4-addr-1.md) |

