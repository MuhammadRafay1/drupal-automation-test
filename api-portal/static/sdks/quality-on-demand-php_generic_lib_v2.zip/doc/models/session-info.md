
# Session Info

Session related information returned in responses.
Note that the device object is defined as optional and will only to be returned if provided in createSession. If more than one type of device identifier was provided, only one identifier will be returned (at implementation choice and with the original value provided in createSession).
Please note that IP addresses of devices can change and get reused, so the original values may no longer identify the same device. They identified the device at the time of session creation.

## Structure

`SessionInfo`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `device` | [`?Device`](../../doc/models/device.md) | Optional | End-user equipment able to connect to a network. Examples of devices include smartphones or IoT sensors/actuators.<br><br>The developer can choose to provide the below specified device identifiers:<br><br>* `ipv4Address`<br>* `ipv6Address`<br>* `phoneNumber`<br>* `networkAccessIdentifier`<br><br>NOTE1: the network operator might support only a subset of these options. The API consumer can provide multiple identifiers to be compatible across different network operators. In this case the identifiers MUST belong to the same device.<br>NOTE2: as for this Commonalities release, we are enforcing that the networkAccessIdentifier is only part of the schema for future-proofing, and CAMARA does not currently allow its use. After the CAMARA meta-release work is concluded and the relevant issues are resolved, its use will need to be explicitly documented in the guidelines. | getDevice(): ?Device | setDevice(?Device device): void |
| `applicationServer` | [`ApplicationServer`](../../doc/models/application-server.md) | Required | A server hosting backend applications to deliver some business logic to clients.<br><br>The developer can choose to provide the below specified device identifiers:<br><br>* `ipv4Address`<br>* `ipv6Address` | getApplicationServer(): ApplicationServer | setApplicationServer(ApplicationServer applicationServer): void |
| `devicePorts` | [`?PortsSpec`](../../doc/models/ports-spec.md) | Optional | The ports used locally by the device for flows to which the requested QoS profile should apply. If omitted, then the qosProfile will apply to all flows between the device and the specified application server address and ports | getDevicePorts(): ?PortsSpec | setDevicePorts(?PortsSpec devicePorts): void |
| `applicationServerPorts` | [`?PortsSpec`](../../doc/models/ports-spec.md) | Optional | A list of single ports or port ranges on the application server | getApplicationServerPorts(): ?PortsSpec | setApplicationServerPorts(?PortsSpec applicationServerPorts): void |
| `qosProfile` | `string` | Required | A unique name for identifying a specific QoS profile.<br>This may follow different formats depending on the API provider implementation.<br>Some options addresses:<br><br>- A UUID style string<br>- Support for predefined profiles QOS_S, QOS_M, QOS_L, and QOS_E<br>- A searchable descriptive name<br>  The set of QoS Profiles that an API provider is offering may be retrieved by means of the QoS Profile API (qos-profile) or agreed on onboarding time.<br><br>**Constraints**: *Minimum Length*: `3`, *Maximum Length*: `256`, *Pattern*: `^[a-zA-Z0-9_.-]+$` | getQosProfile(): string | setQosProfile(string qosProfile): void |
| `sink` | `?string` | Optional | The address to which events about all status changes of the session (e.g. session termination) shall be delivered using the selected protocol. | getSink(): ?string | setSink(?string sink): void |
| `sinkCredential` | [`?SinkCredential`](../../doc/models/sink-credential.md) | Optional | A sink credential provides authentication or authorization information necessary to enable delivery of events to a target. | getSinkCredential(): ?SinkCredential | setSinkCredential(?SinkCredential sinkCredential): void |
| `sessionId` | `string` | Required | Session ID in UUID format | getSessionId(): string | setSessionId(string sessionId): void |
| `duration` | `int` | Required | Session duration in seconds. Implementations can grant the requested session duration or set a different duration, based on network policies or conditions.<br><br>- When `qosStatus` is "REQUESTED", the value is the duration to be scheduled, granted by the implementation.<br>- When `qosStatus` is AVAILABLE", the value is the overall duration since `startedAt. When the session is extended, the value is the new overall duration of the session.<br>- When `qosStatus` is "UNAVAILABLE", the value is the overall effective duration since `startedAt` until the session was terminated.<br><br>**Constraints**: `>= 1` | getDuration(): int | setDuration(int duration): void |
| `startedAt` | `?DateTime` | Optional | Date and time when the QoS status became "AVAILABLE". Not to be returned when `qosStatus` is "REQUESTED". Format must follow RFC 3339 and must indicate time zone (UTC or local). | getStartedAt(): ?\DateTime | setStartedAt(?\DateTime startedAt): void |
| `expiresAt` | `?DateTime` | Optional | Date and time of the QoS session expiration. Format must follow RFC 3339 and must indicate time zone (UTC or local).<br><br>- When `qosStatus` is "AVAILABLE", it is the limit time when the session is scheduled to finnish, if not terminated by other means.<br>- When `qosStatus` is "UNAVAILABLE", it is the time when the session was terminated.<br>- Not to be returned when `qosStatus` is "REQUESTED".<br>  When the session is extended, the value is the new expiration time of the session. | getExpiresAt(): ?\DateTime | setExpiresAt(?\DateTime expiresAt): void |
| `qosStatus` | [`string(QosStatusEnum)`](../../doc/models/qos-status-enum.md) | Required | The current status of the requested QoS session. The status can be one of the following:<br><br>* `REQUESTED` - QoS has been requested by creating a session<br>* `AVAILABLE` - The requested QoS has been provided by the network<br>* `UNAVAILABLE` - The requested QoS cannot be provided by the network due to some reason | getQosStatus(): string | setQosStatus(string qosStatus): void |
| `statusInfo` | [`?string(StatusInfoEnum)`](../../doc/models/status-info-enum.md) | Optional | Reason for the new `qosStatus`. Currently `statusInfo` is only applicable when `qosStatus` is 'UNAVAILABLE'.<br><br>* `DURATION_EXPIRED` - Session terminated due to requested duration expired<br>* `NETWORK_TERMINATED` - Network terminated the session before the requested duration expired<br>* `DELETE_REQUESTED`- User requested the deletion of the session before the requested duration expired | getStatusInfo(): ?string | setStatusInfo(?string statusInfo): void |

## Example (as JSON)

```json
{
  "applicationServer": {
    "ipv4Address": "198.51.100.0/24",
    "ipv6Address": "2001:db8:85a3:8d3:1319:8a2e:370:7344"
  },
  "qosProfile": "voice",
  "sink": "https://endpoint.example.com/sink",
  "sessionId": "00001f70-0000-0000-0000-000000000000",
  "duration": 3600,
  "startedAt": "06/01/2024 12:00:00",
  "expiresAt": "06/01/2024 13:00:00",
  "qosStatus": "REQUESTED",
  "device": {
    "phoneNumber": "phoneNumber4",
    "networkAccessIdentifier": "networkAccessIdentifier6",
    "ipv4Address": {
      "publicAddress": "publicAddress0",
      "privateAddress": "privateAddress6",
      "publicPort": 242
    },
    "ipv6Address": "ipv6Address0"
  },
  "devicePorts": {
    "ranges": [
      {
        "from": 152,
        "to": 232
      },
      {
        "from": 152,
        "to": 232
      }
    ],
    "ports": [
      63
    ]
  },
  "applicationServerPorts": {
    "ranges": [
      {
        "from": 152,
        "to": 232
      },
      {
        "from": 152,
        "to": 232
      },
      {
        "from": 152,
        "to": 232
      }
    ],
    "ports": [
      241,
      242,
      243
    ]
  },
  "sinkCredential": {
    "credentialType": "SinkCredential"
  }
}
```

