
# Code 4 Enum

Code given to this error

## Enumeration

`Code4Enum`

## Fields

| Name |
|  --- |
| `INVALID_ARGUMENT` |
| `OUT_OF_RANGE` |

