
# Session in Conflict 409 Exception

## Structure

`SessionInConflict409Exception`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `status` | `int` | Required, Constant | HTTP status code returned along with this error response<br><br>**Value**: `409` | getStatus(): int | setStatus(int status): void |
| `code` | `string` | Required, Constant | Code given to this error<br><br>**Value**: `'CONFLICT'` | getCode(): string | setCode(string code): void |
| `message` | `string` | Required | Detailed error description | getMessage(): string | setMessage(string message): void |

## Example (as JSON)

```json
{
  "status": 409,
  "code": "CONFLICT",
  "message": "message8"
}
```

