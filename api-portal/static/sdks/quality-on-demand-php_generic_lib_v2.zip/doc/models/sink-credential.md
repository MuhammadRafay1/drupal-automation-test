
# Sink Credential

## Structure

`SinkCredential`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `credentialType` | `?string` | Optional | - | getCredentialType(): ?string | setCredentialType(?string credentialType): void |

## Example (as JSON)

```json
{
  "credentialType": "SinkCredential"
}
```

