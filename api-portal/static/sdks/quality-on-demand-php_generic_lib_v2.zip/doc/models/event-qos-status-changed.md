
# Event Qos Status Changed

Event to notify a QoS status change

## Structure

`EventQosStatusChanged`

## Inherits From

[`CloudEvent`](../../doc/models/cloud-event.md)

## Fields

|  |
| 

## Example (as JSON)

```json
{
  "type": "org.camaraproject.quality-on-demand.v1.qos-status-changed",
  "id": "id8",
  "source": "source6",
  "specversion": "specversion4",
  "datacontenttype": "application/json",
  "data": {
    "key1": "val1",
    "key2": "val2"
  },
  "time": "2016-03-13T12:52:32.123Z"
}
```

