
# Device Ipv 4 Addr 1

## Structure

`DeviceIpv4Addr1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `publicAddress` | `string` | Required | A single IPv4 address with no subnet mask | getPublicAddress(): string | setPublicAddress(string publicAddress): void |
| `privateAddress` | `?string` | Optional | A single IPv4 address with no subnet mask | getPrivateAddress(): ?string | setPrivateAddress(?string privateAddress): void |
| `publicPort` | `int` | Required | TCP or UDP port number<br><br>**Constraints**: `>= 0`, `<= 65535` | getPublicPort(): int | setPublicPort(int publicPort): void |

## Example (as JSON)

```json
{
  "publicAddress": "203.0.113.0",
  "privateAddress": "203.0.113.0",
  "publicPort": 240
}
```

