
# Cloud Event

Event compliant with the CloudEvents specification

## Structure

`CloudEvent`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `string` | Required | Identifier of this event, that must be unique in the source context. | getId(): string | setId(string id): void |
| `source` | `string` | Required | Identifies the context in which an event happened in the specific provider implementation. | getSource(): string | setSource(string source): void |
| `type` | `?string` | Optional | - | getType(): ?string | setType(?string type): void |
| `specversion` | `string` | Required, Constant | Version of the specification to which this event conforms (must be 1.0 if it conforms to Cloudevents 1.0.2 version)<br><br>**Value**: `'1.0'` | getSpecversion(): string | setSpecversion(string specversion): void |
| `datacontenttype` | [`?string(DatacontenttypeEnum)`](../../doc/models/datacontenttype-enum.md) | Optional | media-type that describes the event payload encoding, must be "application/json" for CAMARA APIs | getDatacontenttype(): ?string | setDatacontenttype(?string datacontenttype): void |
| `data` | `?array` | Optional | Event notification details payload, which depends on the event type | getData(): ?array | setData(?array data): void |
| `time` | `DateTime` | Required | Timestamp of when the occurrence happened. It must follow RFC 3339 | getTime(): \DateTime | setTime(\DateTime time): void |

## Example (as JSON)

```json
{
  "id": "id8",
  "source": "source6",
  "specversion": "1.0",
  "time": "2016-03-13T12:52:32.123Z",
  "type": "CloudEvent",
  "datacontenttype": "application/json",
  "data": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

