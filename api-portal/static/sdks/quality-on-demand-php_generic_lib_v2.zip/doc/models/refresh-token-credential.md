
# Refresh Token Credential

An access token credential with a refresh token. MUST not be used in this API version.

## Structure

`RefreshTokenCredential`

## Inherits From

[`SinkCredential`](../../doc/models/sink-credential.md)

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `accessToken` | `string` | Required | REQUIRED. An access token is a previously acquired token granting access to the target resource. | getAccessToken(): string | setAccessToken(string accessToken): void |
| `accessTokenExpiresUtc` | `DateTime` | Required | REQUIRED. An absolute UTC instant at which the token shall be considered expired. | getAccessTokenExpiresUtc(): \DateTime | setAccessTokenExpiresUtc(\DateTime accessTokenExpiresUtc): void |
| `accessTokenType` | `string` | Required, Constant | REQUIRED. Type of the access token (See [OAuth 2.0](https://tools.ietf.org/html/rfc6749#section-7.1)).<br><br>**Value**: `'bearer'` | getAccessTokenType(): string | setAccessTokenType(string accessTokenType): void |
| `refreshToken` | `string` | Required | REQUIRED. An refresh token credential used to acquire access tokens. | getRefreshToken(): string | setRefreshToken(string refreshToken): void |
| `refreshTokenEndpoint` | `string` | Required | REQUIRED. A URL at which the refresh token can be traded for an access token. | getRefreshTokenEndpoint(): string | setRefreshTokenEndpoint(string refreshTokenEndpoint): void |

## Example (as JSON)

```json
{
  "accessToken": "accessToken6",
  "accessTokenExpiresUtc": "2016-03-13T12:52:32.123Z",
  "accessTokenType": "bearer",
  "refreshToken": "refreshToken6",
  "refreshTokenEndpoint": "refreshTokenEndpoint6",
  "credentialType": "REFRESHTOKEN"
}
```

