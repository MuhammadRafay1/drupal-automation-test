
# Session Status Conflict 409 Exception

## Structure

`SessionStatusConflict409Exception`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `status` | `int` | Required, Constant | HTTP status code returned along with this error response<br><br>**Value**: `409` | getStatus(): int | setStatus(int status): void |
| `code` | `string` | Required, Constant | Code given to this error<br><br>**Value**: `'QUALITY_ON_DEMAND.SESSION_EXTENSION_NOT_ALLOWED'` | getCode(): string | setCode(string code): void |
| `message` | `string` | Required | Detailed error description | getMessage(): string | setMessage(string message): void |

## Example (as JSON)

```json
{
  "status": 409,
  "code": "QUALITY_ON_DEMAND.SESSION_EXTENSION_NOT_ALLOWED",
  "message": "message4"
}
```

