
# OAuth 2 Bearer token



Documentation for accessing and setting credentials for openId.

## Auth Credentials

| Name | Type | Description | Setter | Getter |
|  --- | --- | --- | --- | --- |
| AccessToken | `string` | The OAuth 2.0 Access Token to use for API requests. | `accessToken` | `getAccessToken()` |



**Note:** Auth credentials can be set using `OpenIdCredentialsBuilder::init()` in `openIdCredentials` method in the client builder and accessed through `getOpenIdCredentials` method in the client instance.

## Usage Example

### Client Initialization

You must provide credentials in the client as shown in the following code snippet.

```php
use QualityOnDemandLib\Authentication\OpenIdCredentialsBuilder;
use QualityOnDemandLib\QualityOnDemandClientBuilder;

$client = QualityOnDemandClientBuilder::init()
    ->openIdCredentials(
        OpenIdCredentialsBuilder::init(
            'AccessToken'
        )
    )
    ->build();
```


