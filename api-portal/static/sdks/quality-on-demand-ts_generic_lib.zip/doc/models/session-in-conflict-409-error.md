
# Session in Conflict 409 Error

## Structure

`SessionInConflict409Error`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status` | `number` | Required, Constant | HTTP status code returned along with this error response<br><br>**Value**: `409` |
| `code` | `string` | Required, Constant | Code given to this error<br><br>**Value**: `'CONFLICT'` |
| `message` | `string` | Required | Detailed error description |

## Example (as JSON)

```json
{
  "status": 409,
  "code": "CONFLICT",
  "message": "message8"
}
```

