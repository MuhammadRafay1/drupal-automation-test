
# Create Session Bad Request 400 Error

## Structure

`CreateSessionBadRequest400Error`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status` | `number` | Required, Constant | HTTP status code returned along with this error response<br><br>**Value**: `400` |
| `code` | [`CodeEnum`](../../doc/models/code-enum.md) | Required | Code given to this error |
| `message` | `string` | Required | Detailed error description |

## Example (as JSON)

```json
{
  "status": 400,
  "code": "INVALID_CREDENTIAL",
  "message": "message0"
}
```

