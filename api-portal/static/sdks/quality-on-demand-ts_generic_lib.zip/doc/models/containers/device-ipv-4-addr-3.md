
# Device Ipv 4 Addr 3

## Class Name

`DeviceIpv4Addr3`

## Cases

| Type |
|  --- |
| [`DeviceIpv4Addr`](../../../doc/models/device-ipv-4-addr.md) |
| [`DeviceIpv4Addr1`](../../../doc/models/device-ipv-4-addr-1.md) |

