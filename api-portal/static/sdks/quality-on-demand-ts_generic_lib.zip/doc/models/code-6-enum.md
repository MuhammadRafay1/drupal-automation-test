
# Code 6 Enum

Code given to this error

## Enumeration

`Code6Enum`

## Fields

| Name |
|  --- |
| `IDENTIFIERMISMATCH` |
| `SERVICENOTAPPLICABLE` |
| `MISSINGIDENTIFIER` |
| `UNSUPPORTEDIDENTIFIER` |
| `UNNECESSARYIDENTIFIER` |

