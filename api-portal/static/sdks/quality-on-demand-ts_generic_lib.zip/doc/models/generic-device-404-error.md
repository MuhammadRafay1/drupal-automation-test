
# Generic Device 404 Error

## Structure

`GenericDevice404Error`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status` | `number` | Required, Constant | HTTP status code returned along with this error response<br><br>**Value**: `404` |
| `code` | [`Code1Enum`](../../doc/models/code-1-enum.md) | Required | Code given to this error |
| `message` | `string` | Required | Detailed error description |

## Example (as JSON)

```json
{
  "status": 404,
  "code": "NOT_FOUND",
  "message": "message2"
}
```

