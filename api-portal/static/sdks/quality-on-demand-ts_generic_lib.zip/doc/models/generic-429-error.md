
# Generic 429 Error

## Structure

`Generic429Error`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status` | `number` | Required, Constant | HTTP status code returned along with this error response<br><br>**Value**: `429` |
| `code` | [`Code3Enum`](../../doc/models/code-3-enum.md) | Required | Code given to this error |
| `message` | `string` | Required | Detailed error description |

## Example (as JSON)

```json
{
  "status": 429,
  "code": "QUOTA_EXCEEDED",
  "message": "message2"
}
```

