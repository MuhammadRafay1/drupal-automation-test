
# Generic 400 Error

## Structure

`Generic400Error`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status` | `number` | Required, Constant | HTTP status code returned along with this error response<br><br>**Value**: `400` |
| `code` | [`Code4Enum`](../../doc/models/code-4-enum.md) | Required | Code given to this error |
| `message` | `string` | Required | Detailed error description |

## Example (as JSON)

```json
{
  "status": 400,
  "code": "INVALID_ARGUMENT",
  "message": "message8"
}
```

