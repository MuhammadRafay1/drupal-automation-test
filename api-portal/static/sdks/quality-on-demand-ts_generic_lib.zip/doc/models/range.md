
# Range

## Structure

`Range`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `from` | `number` | Required | TCP or UDP port number<br><br>**Constraints**: `>= 0`, `<= 65535` |
| `to` | `number` | Required | TCP or UDP port number<br><br>**Constraints**: `>= 0`, `<= 65535` |

## Example (as JSON)

```json
{
  "from": 92,
  "to": 12
}
```

