
# Sink Credential

## Structure

`SinkCredential`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `credentialType` | `string \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "credentialType": "SinkCredential"
}
```

