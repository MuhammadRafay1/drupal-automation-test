
# Session Status Conflict 409 Error

## Structure

`SessionStatusConflict409Error`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status` | `number` | Required, Constant | HTTP status code returned along with this error response<br><br>**Value**: `409` |
| `code` | `string` | Required, Constant | Code given to this error<br><br>**Value**: `'QUALITY_ON_DEMAND.SESSION_EXTENSION_NOT_ALLOWED'` |
| `message` | `string` | Required | Detailed error description |

## Example (as JSON)

```json
{
  "status": 409,
  "code": "QUALITY_ON_DEMAND.SESSION_EXTENSION_NOT_ALLOWED",
  "message": "message4"
}
```

