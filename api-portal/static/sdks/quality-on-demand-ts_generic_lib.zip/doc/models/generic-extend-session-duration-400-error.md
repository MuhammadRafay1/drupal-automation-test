
# Generic Extend Session Duration 400 Error

## Structure

`GenericExtendSessionDuration400Error`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status` | `number` | Required, Constant | HTTP status code returned along with this error response<br><br>**Value**: `400` |
| `code` | [`Code5Enum`](../../doc/models/code-5-enum.md) | Required | Code given to this error |
| `message` | `string` | Required | Detailed error description |

## Example (as JSON)

```json
{
  "status": 400,
  "code": "INVALID_ARGUMENT",
  "message": "message4"
}
```

