
# Refresh Token Credential

An access token credential with a refresh token. MUST not be used in this API version.

## Structure

`RefreshTokenCredential`

## Inherits From

[`SinkCredential`](../../doc/models/sink-credential.md)

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accessToken` | `string` | Required | REQUIRED. An access token is a previously acquired token granting access to the target resource. |
| `accessTokenExpiresUtc` | `string` | Required | REQUIRED. An absolute UTC instant at which the token shall be considered expired. |
| `accessTokenType` | `string` | Required, Constant | REQUIRED. Type of the access token (See [OAuth 2.0](https://tools.ietf.org/html/rfc6749#section-7.1)).<br><br>**Value**: `'bearer'` |
| `refreshToken` | `string` | Required | REQUIRED. An refresh token credential used to acquire access tokens. |
| `refreshTokenEndpoint` | `string` | Required | REQUIRED. A URL at which the refresh token can be traded for an access token. |

## Example (as JSON)

```json
{
  "accessToken": "accessToken6",
  "accessTokenExpiresUtc": "2016-03-13T12:52:32.123Z",
  "accessTokenType": "bearer",
  "refreshToken": "refreshToken6",
  "refreshTokenEndpoint": "refreshTokenEndpoint6",
  "credentialType": "REFRESHTOKEN"
}
```

