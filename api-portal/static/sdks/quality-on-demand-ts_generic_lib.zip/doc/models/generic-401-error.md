
# Generic 401 Error

## Structure

`Generic401Error`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status` | `number` | Required, Constant | HTTP status code returned along with this error response<br><br>**Value**: `401` |
| `code` | `string` | Required, Constant | Code given to this error<br><br>**Value**: `'UNAUTHENTICATED'` |
| `message` | `string` | Required | Detailed error description |

## Example (as JSON)

```json
{
  "status": 401,
  "code": "UNAUTHENTICATED",
  "message": "message2"
}
```

