
# Client Class Documentation

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| apiRoot | `string` | API root, defined by the service provider, e.g. `api.example.com` or `api.example.com/somepath`<br>*Default*: `'http://localhost:9091'` |
| environment | `Environment` | The API environment. <br> **Default: `Environment.Production`** |
| timeout | `number` | Timeout for API calls.<br>*Default*: `0` |
| httpClientOptions | [`Partial<HttpClientOptions>`](../doc/http-client-options.md) | Stable configurable http client options. |
| unstableHttpClientOptions | `any` | Unstable configurable http client options. |
| openIdCredentials | [`OpenIdCredentials`](auth/oauth-2-bearer-token.md) | The credential object for openId |
| notificationsBearerAuthCredentials | [`NotificationsBearerAuthCredentials`](auth/oauth-2-bearer-token-1.md) | The credential object for notificationsBearerAuth |

The API client can be initialized as follows:

```ts
const client = new Client({
  openIdCredentials: {
    accessToken: 'AccessToken'
  },
  notificationsBearerAuthCredentials: {
    accessToken: 'AccessToken'
  },
  timeout: 0,
  environment: Environment.Production,
  apiRoot: 'http://localhost:9091',
});
```

## Quality-On-Demand Client

The gateway for the SDK. This class acts as a factory for the Controllers and also holds the configuration of the SDK.

## Controllers

| Name | Description |
|  --- | --- |
| qoSSessions | Gets QoSSessionsController |

