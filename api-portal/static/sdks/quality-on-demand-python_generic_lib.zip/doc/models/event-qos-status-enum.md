
# Event Qos Status Enum

The current status of a requested or previously available session. Applicable values in the event are:

* `AVAILABLE` - The requested QoS has been provided by the network.
* `UNAVAILABLE` - A requested or previously available QoS session is now unavailable. `statusInfo` may provide additional information about the reason for the unavailability.

## Enumeration

`EventQosStatusEnum`

## Fields

| Name |
|  --- |
| `AVAILABLE` |
| `UNAVAILABLE` |

