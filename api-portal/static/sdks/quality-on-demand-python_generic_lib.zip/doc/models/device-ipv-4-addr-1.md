
# Device Ipv 4 Addr 1

## Structure

`DeviceIpv4Addr1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `public_address` | `str` | Required | A single IPv4 address with no subnet mask |
| `private_address` | `str` | Optional | A single IPv4 address with no subnet mask |
| `public_port` | `int` | Required | TCP or UDP port number<br><br>**Constraints**: `>= 0`, `<= 65535` |

## Example (as JSON)

```json
{
  "publicAddress": "203.0.113.0",
  "privateAddress": "203.0.113.0",
  "publicPort": 240
}
```

