
# Code 1 Enum

Code given to this error

## Enumeration

`Code1Enum`

## Fields

| Name |
|  --- |
| `NOT_FOUND` |
| `IDENTIFIER_NOT_FOUND` |

