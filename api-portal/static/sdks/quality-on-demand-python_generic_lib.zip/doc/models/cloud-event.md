
# Cloud Event

Event compliant with the CloudEvents specification

## Structure

`CloudEvent`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `str` | Required | Identifier of this event, that must be unique in the source context. |
| `source` | `str` | Required | Identifies the context in which an event happened in the specific provider implementation. |
| `mtype` | `str` | Optional | - |
| `specversion` | `str` | Required, Constant | Version of the specification to which this event conforms (must be 1.0 if it conforms to Cloudevents 1.0.2 version)<br><br>**Value**: `'1.0'` |
| `datacontenttype` | [`DatacontenttypeEnum`](../../doc/models/datacontenttype-enum.md) | Optional | media-type that describes the event payload encoding, must be "application/json" for CAMARA APIs |
| `data` | `Any` | Optional | Event notification details payload, which depends on the event type |
| `time` | `datetime` | Required | Timestamp of when the occurrence happened. It must follow RFC 3339 |

## Example (as JSON)

```json
{
  "id": "id8",
  "source": "source6",
  "specversion": "1.0",
  "time": "2016-03-13T12:52:32.123Z",
  "type": "CloudEvent",
  "datacontenttype": "application/json",
  "data": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

