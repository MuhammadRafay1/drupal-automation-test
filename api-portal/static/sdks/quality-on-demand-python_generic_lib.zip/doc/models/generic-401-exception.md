
# Generic 401 Exception

## Structure

`Generic401Exception`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status` | `int` | Required, Constant | HTTP status code returned along with this error response<br><br>**Value**: `401` |
| `code` | `str` | Required, Constant | Code given to this error<br><br>**Value**: `'UNAUTHENTICATED'` |
| `message` | `str` | Required | Detailed error description |

## Example (as JSON)

```json
{
  "status": 401,
  "code": "UNAUTHENTICATED",
  "message": "message2"
}
```

