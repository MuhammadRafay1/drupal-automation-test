
# Generic 400 Exception

## Structure

`Generic400Exception`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status` | `int` | Required, Constant | HTTP status code returned along with this error response<br><br>**Value**: `400` |
| `code` | [`Code4Enum`](../../doc/models/code-4-enum.md) | Required | Code given to this error |
| `message` | `str` | Required | Detailed error description |

## Example (as JSON)

```json
{
  "status": 400,
  "code": "INVALID_ARGUMENT",
  "message": "message8"
}
```

