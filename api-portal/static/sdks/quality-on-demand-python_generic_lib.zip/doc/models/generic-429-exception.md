
# Generic 429 Exception

## Structure

`Generic429Exception`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status` | `int` | Required, Constant | HTTP status code returned along with this error response<br><br>**Value**: `429` |
| `code` | [`Code3Enum`](../../doc/models/code-3-enum.md) | Required | Code given to this error |
| `message` | `str` | Required | Detailed error description |

## Example (as JSON)

```json
{
  "status": 429,
  "code": "QUOTA_EXCEEDED",
  "message": "message2"
}
```

