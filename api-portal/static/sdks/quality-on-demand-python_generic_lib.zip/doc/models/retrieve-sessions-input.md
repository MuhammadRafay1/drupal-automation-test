
# Retrieve Sessions Input

Parameters to get QoS session information by device

## Structure

`RetrieveSessionsInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `device` | [`Device`](../../doc/models/device.md) | Optional | End-user equipment able to connect to a network. Examples of devices include smartphones or IoT sensors/actuators.<br><br>The developer can choose to provide the below specified device identifiers:<br><br>* `ipv4Address`<br>* `ipv6Address`<br>* `phoneNumber`<br>* `networkAccessIdentifier`<br><br>NOTE1: the network operator might support only a subset of these options. The API consumer can provide multiple identifiers to be compatible across different network operators. In this case the identifiers MUST belong to the same device.<br>NOTE2: as for this Commonalities release, we are enforcing that the networkAccessIdentifier is only part of the schema for future-proofing, and CAMARA does not currently allow its use. After the CAMARA meta-release work is concluded and the relevant issues are resolved, its use will need to be explicitly documented in the guidelines. |

## Example (as JSON)

```json
{
  "device": {
    "phoneNumber": "phoneNumber4",
    "networkAccessIdentifier": "networkAccessIdentifier6",
    "ipv4Address": {
      "publicAddress": "publicAddress0",
      "privateAddress": "privateAddress6",
      "publicPort": 242
    },
    "ipv6Address": "ipv6Address0"
  }
}
```

