
# Generic 422 Exception

## Structure

`Generic422Exception`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status` | `int` | Required, Constant | HTTP status code returned along with this error response<br><br>**Value**: `422` |
| `code` | [`Code6Enum`](../../doc/models/code-6-enum.md) | Required | Code given to this error |
| `message` | `str` | Required | Detailed error description |

## Example (as JSON)

```json
{
  "status": 422,
  "code": "UNNECESSARY_IDENTIFIER",
  "message": "message6"
}
```

