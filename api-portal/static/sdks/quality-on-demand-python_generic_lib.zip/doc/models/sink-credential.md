
# Sink Credential

## Structure

`SinkCredential`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `credential_type` | `str` | Optional | - |

## Example (as JSON)

```json
{
  "credentialType": "SinkCredential"
}
```

