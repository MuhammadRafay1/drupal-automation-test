
# Error Info

Common schema for errors

## Structure

`ErrorInfo`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status` | `int` | Required | HTTP status code returned along with this error response |
| `code` | `str` | Required | Code given to this error |
| `message` | `str` | Required | Detailed error description |

## Example (as JSON)

```json
{
  "status": 222,
  "code": "code6",
  "message": "message8"
}
```

