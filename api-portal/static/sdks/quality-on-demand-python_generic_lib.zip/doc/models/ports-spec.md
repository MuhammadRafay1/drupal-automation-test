
# Ports Spec

Specification of several TCP or UDP ports

## Structure

`PortsSpec`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ranges` | [`List[Range]`](../../doc/models/range.md) | Optional | Range of TCP or UDP ports<br><br>**Constraints**: *Minimum Items*: `1` |
| `ports` | `List[int]` | Optional | Array of TCP or UDP ports<br><br>**Constraints**: *Minimum Items*: `1`, `>= 0`, `<= 65535` |

## Example (as JSON)

```json
{
  "ranges": [
    {
      "from": 5010,
      "to": 5020
    }
  ],
  "ports": [
    5060,
    5070
  ]
}
```

