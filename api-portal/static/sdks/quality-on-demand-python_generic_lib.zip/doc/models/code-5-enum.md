
# Code 5 Enum

Code given to this error

## Enumeration

`Code5Enum`

## Fields

| Name |
|  --- |
| `INVALID_ARGUMENT` |
| `OUT_OF_RANGE` |
| `ENUM_QUALITY_ON_DEMANDDURATION_OUT_OF_RANGE` |

