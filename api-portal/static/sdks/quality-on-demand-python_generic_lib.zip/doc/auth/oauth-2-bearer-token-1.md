
# OAuth 2 Bearer token



Documentation for accessing and setting credentials for notificationsBearerAuth.

## Auth Credentials

| Name | Type | Description | Getter |
|  --- | --- | --- | --- |
| AccessToken | `str` | The OAuth 2.0 Access Token to use for API requests. | `access_token` |



**Note:** Auth credentials can be set using `NotificationsBearerAuthCredentials` object, passed in as named parameter `notifications_bearer_auth_credentials` in the client initialization.

## Usage Example

### Client Initialization

You must provide credentials in the client as shown in the following code snippet.

```python
client = QualityondemandClient(
    notifications_bearer_auth_credentials=NotificationsBearerAuthCredentials(
        access_token='AccessToken'
    )
)
```


